# Passregel-Vergleich, Stufe A (Auslösung)

Reine Rechnung auf Archivdaten (Schalter 1 in diesem Prozess). Keine Partie, kein GNU Go.

Zeilen gelesen: 2760, ausgewertet: 2760; übersprungen: {}

| Gruppe | Partien | Einheiten (vor Deckel) | Einheiten | ausgelöst Fläche | ausgelöst Territory | ohne Auslösung Fläche | ohne Auslösung Territory |
|---|---:|---:|---:|---:|---:|---:|---:|
| GNU Go ohne Vorgabe | 960 | 2 | 2 | 2 | 2 | 958 | 958 |
| Fuego 100 Spiele | 480 | 45 | 45 | 44 | 43 | 436 | 437 |
| Fuego 50 Spiele | 960 | 317 | 317 | 317 | 301 | 643 | 659 |
| alte PWA | 360 | 199 | 199 | 198 | 174 | 162 | 186 |

### Aufschlüsselung nach KI-Farbe

| Gruppe | KI-Farbe | Partien | ausgelöst Fläche | ausgelöst Territory |
|---|---|---:|---:|---:|
| GNU Go ohne Vorgabe | Schwarz | 480 | 1 | 1 |
| GNU Go ohne Vorgabe | Weiß | 480 | 1 | 1 |
| Fuego 100 Spiele | Schwarz | 240 | 10 | 8 |
| Fuego 100 Spiele | Weiß | 240 | 34 | 35 |
| Fuego 50 Spiele | Schwarz | 480 | 104 | 97 |
| Fuego 50 Spiele | Weiß | 480 | 213 | 204 |
| alte PWA | Schwarz | 180 | 91 | 81 |
| alte PWA | Weiß | 180 | 107 | 93 |

### Werte an der Auslösung (aus Sicht der KI: mit Annahmen, nur Bewiesenes, Spanne, gemischter Anteil)

| Wertung | Auswahl | Einheiten | mit | nur | Spanne | gemischt |
|---|---|---:|---|---|---|---|
| flaeche | alle | 561 | 68,6 (Median 61,5; 20,5 bis 230,5) | 68,6 (Median 61,5; 20,5 bis 230,5) | 0,098 (max 2,000) | 0,010 (max 0,243) |
| flaeche | KI Schwarz | 206 | 63,2 (Median 57,5; 20,5 bis 211,5) | 63,2 (Median 57,5; 20,5 bis 211,5) | 0,121 (max 2,000) | 0,013 (max 0,171) |
| flaeche | KI Weiß | 355 | 71,7 (Median 64,5; 20,5 bis 230,5) | 71,7 (Median 64,5; 20,5 bis 230,5) | 0,085 (max 2,000) | 0,009 (max 0,243) |
| territory | alle | 520 | 65,7 (Median 59,0; 20,5 bis 224,5) | 65,7 (Median 58,5; 20,5 bis 224,5) | 0,090 (max 2,000) | 0,009 (max 0,243) |
| territory | KI Schwarz | 187 | 58,7 (Median 50,5; 20,5 bis 204,5) | 58,7 (Median 50,5; 20,5 bis 204,5) | 0,123 (max 2,000) | 0,012 (max 0,171) |
| territory | KI Weiß | 333 | 69,6 (Median 63,5; 20,5 bis 224,5) | 69,6 (Median 63,5; 20,5 bis 224,5) | 0,072 (max 2,000) | 0,008 (max 0,243) |

Geprüfte Stellungen (Gegnerpass, KI am Zug): 56345

| Grund | Fläche | Territory |
|---|---:|---:|
| ausgelöst | 561 | 520 |
| nicht ausgespielt | 20090 | 20093 |
| ungeklärte Gruppen (Spanne) | 32270 | 32433 |
| Vorsprung zu klein | 2850 | 3282 |

Einheiten nach Abzug der Duplikate: Fläche 561, Territory 520 (Einheiten gesamt 563). Duplikate (gleiche Zugfolge bis zur Stellung, nur einmal gezählt): 0.
Kriterium aus §8: mindestens 183 Auslösungen je Wertung bei K = 0: Fläche erreicht, Territory erreicht.

Pflichtprüfungen Stufe A: bestanden.
