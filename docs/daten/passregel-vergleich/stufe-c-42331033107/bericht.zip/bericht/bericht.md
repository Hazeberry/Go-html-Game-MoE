# Passregel-Vergleich, Hauptlauf (Stufe C)

Einheiten aus Stufe A: 563; Ergebniszeilen: 563.

**Lauf gültig.**

## Pflichtprüfungen und Kontrollen

- flaeche: N 561, Ausfälle 0 (0,00 %), davon ohne Ergebnis 0, Pflichtfehler 0
- territory: N 520, Ausfälle 0 (0,00 %), davon ohne Ergebnis 0, Pflichtfehler 0
- Nachspiel-Kontrolle am Archiv (§9 Nr. 4): bestanden; GNU Go ohne Vorgabe 10/10, Fuego 100 Spiele 10/10, Fuego 50 Spiele 10/10, alte PWA 10/10
    - bestätigt: Archivzugfolge in GNU Go regelkonform einspielbar; GNU Gos final_score der Schlussstellung gleich dem archivierten Endstand
    - nicht bestätigt: Dass die heutige Engine dieselben Züge wählen würde; Brett und Gefangene der Engine (prüft die Fortsetzung je Einheit)
- Wiederholbarkeit (§9 Nr. 7, nur Probe verlangt; Gegner gnugo und ki müssen gleich sein, fuego wird berichtet): fuego: 0/3 Einheiten erfüllt (je 1 Wiederholungsläufe, Einheiten 362), vollständige Läufe 0, davon gleich in Zugfolge und Stand 0 (versucht 0, unvollständig 0) (Gleichheit nur berichtet); gnugo: 0/2 Einheiten erfüllt (je 2 Wiederholungsläufe, Einheiten 2), vollständige Läufe 0, davon gleich in Zugfolge und Stand 0 (versucht 0, unvollständig 0); ki: 0/3 Einheiten erfüllt (je 1 Wiederholungsläufe, Einheiten 199), vollständige Läufe 0, davon gleich in Zugfolge und Stand 0 (versucht 0, unvollständig 0)
- KI-Züge in den Fortsetzungen (technisch): 563 reguläre, Steinzüge 0 bis 77 (Median 20), ohne KI-Steinzug: 8
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|26|335 (anfang): final_score "B+82.5", Fläche aus Tot-Liste 73.5, Unterschied -9, tote Steine 2
    - Bestandteile (unsere Zählung): Schwarz Steine 160 + Gebiet 61, Weiß Steine 104 + Gebiet 36, neutral 0, tote Steine S/W 0/2
    - Punktabweichungen: R19 (GNU Go seki-W, unser Besitzer W); S19 (GNU Go dame, unser Besitzer W); T19 (GNU Go dame, unser Besitzer W); Q18 (GNU Go seki-W, unser Besitzer W); R18 (GNU Go seki-W, unser Besitzer W); S18 (GNU Go dame, unser Besitzer W); T18 (GNU Go dame, unser Besitzer W); R17 (GNU Go seki-W, unser Besitzer W); S17 (GNU Go dame, unser Besitzer W); T17 (GNU Go dame, unser Besitzer W); Q16 (GNU Go seki-W, unser Besitzer W); R16 (GNU Go seki-W, unser Besitzer W); S16 (GNU Go dame, unser Besitzer W); T16 (GNU Go dame, unser Besitzer W); R15 (GNU Go seki-W, unser Besitzer W); S15 (GNU Go seki-W, unser Besitzer W); T15 (GNU Go seki-W, unser Besitzer W)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|26|335 (ende): final_score "B+82.5", Fläche aus Tot-Liste 81.5, Unterschied -1, tote Steine 0
    - Bestandteile (unsere Zählung): Schwarz Steine 178 + Gebiet 44, Weiß Steine 112 + Gebiet 21, neutral 6, tote Steine S/W 0/0
    - Punktabweichungen: R19 (GNU Go seki-W, unser Besitzer W); Q18 (GNU Go seki-W, unser Besitzer W); R18 (GNU Go seki-W, unser Besitzer W); S18 (GNU Go seki-W, unser Besitzer W); R17 (GNU Go seki-W, unser Besitzer W); S17 (GNU Go seki-S, unser Besitzer S); Q16 (GNU Go seki-W, unser Besitzer W); R16 (GNU Go seki-W, unser Besitzer W); R15 (GNU Go seki-W, unser Besitzer W); S15 (GNU Go seki-W, unser Besitzer W); T15 (GNU Go seki-W, unser Besitzer W)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|286|311 (anfang): final_score "B+11.5", Fläche aus Tot-Liste 21.5, Unterschied 10, tote Steine 6
    - Bestandteile (unsere Zählung): Schwarz Steine 132 + Gebiet 53, Weiß Steine 119 + Gebiet 37, neutral 20, tote Steine S/W 4/2
    - Punktabweichungen: J19 (GNU Go gebiet-W, unser Besitzer neutral); K19 (GNU Go gebiet-W, unser Besitzer neutral); L19 (GNU Go gebiet-W, unser Besitzer neutral); M19 (GNU Go gebiet-W, unser Besitzer neutral); N19 (GNU Go gebiet-W, unser Besitzer neutral); O19 (GNU Go gebiet-W, unser Besitzer neutral); P19 (GNU Go gebiet-W, unser Besitzer neutral); J18 (GNU Go gebiet-W, unser Besitzer neutral); J17 (GNU Go gebiet-W, unser Besitzer neutral); E5 (GNU Go gebiet-S, unser Besitzer neutral); E4 (GNU Go gebiet-S, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|132|301 (anfang): final_score "B+43.5", Fläche aus Tot-Liste 44.5, Unterschied 1, tote Steine 11
    - Bestandteile (unsere Zählung): Schwarz Steine 136 + Gebiet 63, Weiß Steine 111 + Gebiet 36, neutral 15, tote Steine S/W 0/11
    - Punktabweichungen: A12 (GNU Go gebiet-S, unser Besitzer neutral); M9 (GNU Go gebiet-S, unser Besitzer neutral); N9 (GNU Go gebiet-S, unser Besitzer neutral); Q9 (GNU Go gebiet-W, unser Besitzer neutral); A8 (GNU Go gebiet-W, unser Besitzer neutral); Q8 (GNU Go gebiet-W, unser Besitzer neutral); A7 (GNU Go gebiet-W, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|73|298 (anfang): final_score "W+40.5", Fläche aus Tot-Liste -39.5, Unterschied 1, tote Steine 9
    - Bestandteile (unsere Zählung): Schwarz Steine 102 + Gebiet 62, Weiß Steine 135 + Gebiet 61, neutral 1, tote Steine S/W 9/0
    - Punktabweichungen: A8 (GNU Go dame, unser Besitzer S)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|41|312 (anfang): final_score "W+54.5", Fläche aus Tot-Liste -83.5, Unterschied -29, tote Steine 18
    - Bestandteile (unsere Zählung): Schwarz Steine 89 + Gebiet 35, Weiß Steine 128 + Gebiet 72, neutral 37, tote Steine S/W 11/7
    - Punktabweichungen: D19 (GNU Go gebiet-S, unser Besitzer neutral); E19 (GNU Go gebiet-S, unser Besitzer neutral); B10 (GNU Go gebiet-S, unser Besitzer neutral); A9 (GNU Go gebiet-S, unser Besitzer neutral); B9 (GNU Go gebiet-S, unser Besitzer neutral); A8 (GNU Go gebiet-S, unser Besitzer neutral); A7 (GNU Go gebiet-S, unser Besitzer neutral); A6 (GNU Go gebiet-S, unser Besitzer neutral); A5 (GNU Go gebiet-S, unser Besitzer neutral); A4 (GNU Go gebiet-S, unser Besitzer neutral); B4 (GNU Go gebiet-S, unser Besitzer neutral); A3 (GNU Go gebiet-S, unser Besitzer neutral); B3 (GNU Go gebiet-S, unser Besitzer neutral); E3 (GNU Go gebiet-S, unser Besitzer neutral); A2 (GNU Go gebiet-S, unser Besitzer neutral); B2 (GNU Go gebiet-S, unser Besitzer neutral); E2 (GNU Go gebiet-S, unser Besitzer neutral); A1 (GNU Go gebiet-S, unser Besitzer neutral); B1 (GNU Go gebiet-S, unser Besitzer neutral); C1 (GNU Go gebiet-S, unser Besitzer neutral); D1 (GNU Go gebiet-S, unser Besitzer neutral); E1 (GNU Go gebiet-S, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|49|318 (anfang): final_score "W+24.5", Fläche aus Tot-Liste -23.5, Unterschied 1, tote Steine 3
    - Bestandteile (unsere Zählung): Schwarz Steine 117 + Gebiet 55, Weiß Steine 133 + Gebiet 55, neutral 1, tote Steine S/W 2/1
    - Punktabweichungen: keine
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) Fuego 50 Spiele|D.jsonl.gz|212|337 (ende): final_score "W+14.5", Fläche aus Tot-Liste -13.5, Unterschied 1, tote Steine 40
    - Bestandteile (unsere Zählung): Schwarz Steine 124 + Gebiet 51, Weiß Steine 113 + Gebiet 68, neutral 5, tote Steine S/W 40/0
    - Punktabweichungen: T7 (GNU Go seki-W, unser Besitzer W); S6 (GNU Go seki-W, unser Besitzer W); T6 (GNU Go seki-W, unser Besitzer W); N5 (GNU Go seki-W, unser Besitzer W); O5 (GNU Go seki-W, unser Besitzer W); P5 (GNU Go seki-W, unser Besitzer W); Q5 (GNU Go seki-W, unser Besitzer W); R5 (GNU Go seki-W, unser Besitzer W); S5 (GNU Go seki-W, unser Besitzer W); M4 (GNU Go seki-W, unser Besitzer W); N4 (GNU Go seki-W, unser Besitzer W); P4 (GNU Go seki-W, unser Besitzer W); Q4 (GNU Go seki-W, unser Besitzer W); S4 (GNU Go seki-S, unser Besitzer S); T4 (GNU Go seki-S, unser Besitzer S); M3 (GNU Go seki-W, unser Besitzer W); N3 (GNU Go seki-W, unser Besitzer W); O3 (GNU Go seki-S, unser Besitzer S); P3 (GNU Go seki-W, unser Besitzer W); Q3 (GNU Go seki-W, unser Besitzer W); R3 (GNU Go seki-W, unser Besitzer W); S3 (GNU Go seki-S, unser Besitzer S); T3 (GNU Go dame, unser Besitzer S); N2 (GNU Go seki-W, unser Besitzer W); O2 (GNU Go seki-W, unser Besitzer W); R2 (GNU Go seki-W, unser Besitzer W); S2 (GNU Go seki-W, unser Besitzer W); T2 (GNU Go seki-S, unser Besitzer S); Q1 (GNU Go seki-W, unser Besitzer W); R1 (GNU Go seki-W, unser Besitzer W)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|142|337 (anfang): final_score "B+43.5", Fläche aus Tot-Liste 42.5, Unterschied -1, tote Steine 1
    - Bestandteile (unsere Zählung): Schwarz Steine 139 + Gebiet 66, Weiß Steine 118 + Gebiet 37, neutral 1, tote Steine S/W 0/1
    - Punktabweichungen: R19 (GNU Go dame, unser Besitzer W); T16 (GNU Go dame, unser Besitzer S)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|226|329 (anfang): final_score "B+65.5", Fläche aus Tot-Liste 68.5, Unterschied 3, tote Steine 16
    - Bestandteile (unsere Zählung): Schwarz Steine 142 + Gebiet 72, Weiß Steine 106 + Gebiet 32, neutral 9, tote Steine S/W 0/16
    - Punktabweichungen: M19 (GNU Go dame, unser Besitzer S); F2 (GNU Go gebiet-W, unser Besitzer neutral); F1 (GNU Go gebiet-W, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|144|321 (anfang): final_score "B+35.5", Fläche aus Tot-Liste 36.5, Unterschied 1, tote Steine 6
    - Bestandteile (unsere Zählung): Schwarz Steine 146 + Gebiet 55, Weiß Steine 116 + Gebiet 41, neutral 3, tote Steine S/W 0/6
    - Punktabweichungen: A11 (GNU Go dame, unser Besitzer S)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|197|294 (anfang): final_score "W+72.5", Fläche aus Tot-Liste -71.5, Unterschied 1, tote Steine 0
    - Bestandteile (unsere Zählung): Schwarz Steine 97 + Gebiet 51, Weiß Steine 138 + Gebiet 74, neutral 1, tote Steine S/W 0/0
    - Punktabweichungen: A15 (GNU Go dame, unser Besitzer S)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|243|300 (anfang): final_score "W+54.5", Fläche aus Tot-Liste -51.5, Unterschied 3, tote Steine 0
    - Bestandteile (unsere Zählung): Schwarz Steine 99 + Gebiet 57, Weiß Steine 136 + Gebiet 64, neutral 5, tote Steine S/W 0/0
    - Punktabweichungen: T19 (GNU Go gebiet-W, unser Besitzer neutral); T18 (GNU Go gebiet-W, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|245|318 (anfang): final_score "W+90.5", Fläche aus Tot-Liste -91.5, Unterschied -1, tote Steine 3
    - Bestandteile (unsere Zählung): Schwarz Steine 97 + Gebiet 40, Weiß Steine 153 + Gebiet 68, neutral 3, tote Steine S/W 3/0
    - Punktabweichungen: K2 (GNU Go gebiet-S, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|206|341 (anfang): final_score "B+139.5", Fläche aus Tot-Liste 136.5, Unterschied -3, tote Steine 20
    - Bestandteile (unsere Zählung): Schwarz Steine 150 + Gebiet 100, Weiß Steine 70 + Gebiet 36, neutral 5, tote Steine S/W 1/19
    - Punktabweichungen: G19 (GNU Go gebiet-S, unser Besitzer neutral); H19 (GNU Go gebiet-S, unser Besitzer neutral); J19 (GNU Go gebiet-S, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|360|335 (anfang): final_score "B+105.5", Fläche aus Tot-Liste 97.5, Unterschied -8, tote Steine 12
    - Bestandteile (unsere Zählung): Schwarz Steine 161 + Gebiet 72, Weiß Steine 102 + Gebiet 26, neutral 0, tote Steine S/W 0/12
    - Punktabweichungen: G10 (GNU Go seki-W, unser Besitzer W); G9 (GNU Go seki-W, unser Besitzer W); E8 (GNU Go seki-W, unser Besitzer W); F8 (GNU Go seki-W, unser Besitzer W); G8 (GNU Go seki-W, unser Besitzer W); H8 (GNU Go seki-W, unser Besitzer W); F7 (GNU Go seki-W, unser Besitzer W); G7 (GNU Go seki-W, unser Besitzer W); F6 (GNU Go seki-W, unser Besitzer W); F5 (GNU Go seki-W, unser Besitzer W); F4 (GNU Go seki-W, unser Besitzer W); G4 (GNU Go seki-W, unser Besitzer W); D3 (GNU Go seki-W, unser Besitzer W); E3 (GNU Go seki-W, unser Besitzer W); F3 (GNU Go seki-W, unser Besitzer W); G3 (GNU Go dame, unser Besitzer W); H3 (GNU Go seki-W, unser Besitzer W); J3 (GNU Go seki-W, unser Besitzer W); E2 (GNU Go seki-W, unser Besitzer W); F2 (GNU Go dame, unser Besitzer W); G2 (GNU Go dame, unser Besitzer W); H2 (GNU Go dame, unser Besitzer W); J2 (GNU Go seki-W, unser Besitzer W); K2 (GNU Go seki-W, unser Besitzer W); D1 (GNU Go seki-W, unser Besitzer W); E1 (GNU Go seki-W, unser Besitzer W); F1 (GNU Go dame, unser Besitzer W); G1 (GNU Go dame, unser Besitzer W); H1 (GNU Go dame, unser Besitzer W); J1 (GNU Go dame, unser Besitzer W); K1 (GNU Go seki-W, unser Besitzer W)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Konvention von GNU Gos `captures` (in der Kalibrierung bestimmt, je Stellung angewendet; Anzahl Stellungen): {"gefangen-von":563}
- Stellungen mit ungleichen Gefangenenzahlen (dort würde ein vertauschter Zähler auffallen): 561 von 563
- Zählvergleich: Fläche aus Tot-Liste ≠ final_score bei 15 Stellung(en): alte PWA|m1.jsonl.gz|26|335, alte PWA|m1.jsonl.gz|286|311, alte PWA|m1.jsonl.gz|132|301, alte PWA|m1.jsonl.gz|73|298, alte PWA|m1.jsonl.gz|41|312, alte PWA|m1.jsonl.gz|49|318, Fuego 50 Spiele|D.jsonl.gz|212|337, alte PWA|m1.jsonl.gz|142|337, alte PWA|m1.jsonl.gz|226|329, alte PWA|m1.jsonl.gz|144|321, alte PWA|m1.jsonl.gz|197|294, alte PWA|m1.jsonl.gz|243|300, alte PWA|m1.jsonl.gz|245|318, alte PWA|m1.jsonl.gz|206|341, alte PWA|m1.jsonl.gz|360|335 (Vergleich zweier Zählverfahren, nicht Teil der Gültigkeit)
- Dauer je Einheit: Mittel 4 s, Maximum 14 s, Summe 0.60 h

## Technische Ausfälle nach Art (Befehl und Fehlertext unverändert)

keine

## Ausfälle (einzeln, §9 Nr. 6)

flaeche: 0
territory: 0

## E1 verlorene Siege (Endpunkt, §7)

### flaeche

N = 561 (alle Auslösungen), L = 0, A = 0, K = L + A = 0, G = 0

- K/N: 0,00 % [0,00 % bis 0,66 %]
- L/N: 0,00 % [0,00 % bis 0,66 %]
- L/W₀ (W₀ = 543, nur beschreibend): 0,00 % [0,00 % bis 0,68 %]
- Grenze 2,0 % erreicht (bei K = 0 braucht es N ≥ 183)
- L gegen G, exakter Test: p = 1.0000 (beschreibend)

| Gruppe | N | L | A | G |
|---|---:|---:|---:|---:|
| GNU Go ohne Vorgabe | 2 | 0 | 0 | 0 |
| Fuego 100 Spiele | 44 | 0 | 0 | 0 |
| Fuego 50 Spiele | 317 | 0 | 0 | 0 |
| alte PWA | 198 | 0 | 0 | 0 |

| KI-Farbe | N | L | A | G |
|---|---:|---:|---:|---:|
| W | 355 | 0 | 0 | 0 |
| S | 206 | 0 | 0 | 0 |

### territory

N = 520 (alle Auslösungen), L = 0, A = 0, K = L + A = 0, G = 4

- K/N: 0,00 % [0,00 % bis 0,71 %]
- L/N: 0,00 % [0,00 % bis 0,71 %]
- L/W₀ (W₀ = 505, nur beschreibend): 0,00 % [0,00 % bis 0,73 %]
- Grenze 2,0 % erreicht (bei K = 0 braucht es N ≥ 183)
- L gegen G, exakter Test: p = 0.1250 (beschreibend)

| Gruppe | N | L | A | G |
|---|---:|---:|---:|---:|
| GNU Go ohne Vorgabe | 2 | 0 | 0 | 1 |
| Fuego 100 Spiele | 43 | 0 | 0 | 1 |
| Fuego 50 Spiele | 301 | 0 | 0 | 1 |
| alte PWA | 174 | 0 | 0 | 1 |

| KI-Farbe | N | L | A | G |
|---|---:|---:|---:|---:|
| W | 333 | 0 | 0 | 1 |
| S | 187 | 0 | 0 | 3 |

## E2 Punktverlust, E3 Züge, Nebenkennzahlen (beschreibend)

### flaeche

- E2: D = „weiter“ − „sofort“ (KI-Sicht), n = 561: Mittel 0,1 [-0,3 bis 0,5], Median 0,0; „weiter“ besser in 11, schlechter in 7, Vorzeichentest p = 0.4807
- E3: KI-Steinzüge in „weiter“ Mittel 20,7, Median 20,0; KI-Pässe Mittel 3,0 (n = 561)
- Auslösung bei verlorener Stellung („sofort“ verliert): 18 von 561; „sofort“ unbekannt: 0
- Zählvorschau minus GNU Go (KI-Sicht, n = 561): „mit Annahmen“ Mittel 1,6, größte Abweichung 122,0; „nur Bewiesenes“ Mittel 1,7, größte Abweichung 122,0

### territory

- E2: D = „weiter“ − „sofort“ (KI-Sicht), n = 520: Mittel -15,1 [-16,1 bis -14,1], Median -15,0; „weiter“ besser in 18, schlechter in 490, Vorzeichentest p = 0.0000
- E3: KI-Steinzüge in „weiter“ Mittel 20,8, Median 20,0; KI-Pässe Mittel 3,0 (n = 520)
- Auslösung bei verlorener Stellung („sofort“ verliert): 11 von 520; „sofort“ unbekannt: 0
- Zählvorschau minus GNU Go (KI-Sicht, n = 520): „mit Annahmen“ Mittel 1,2, größte Abweichung 122,0; „nur Bewiesenes“ Mittel 1,2, größte Abweichung 122,0

## Befund

**Die obere Konfidenzgrenze für den Anteil verlorener Siege liegt unter den Modellannahmen bei höchstens 2 %.**


Das Urteil betrifft ausschließlich den Anteil verlorener Siege pro Auslösung (K/N, beide Wertungen). Punktverluste bei weiterhin gewonnenen Partien und andere Verschlechterungen erfasst es nicht (E2, E3 getrennt). Die Intervalle gelten unter der Modellannahme unabhängiger Einheiten (§10) und nur für dieses Material.
