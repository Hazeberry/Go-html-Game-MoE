# Passregel-Vergleich, technische Probe (Stufe B)

Einheiten aus Stufe A: 11; Ergebniszeilen: 11.

**Lauf gültig.**

## Pflichtprüfungen und Kontrollen

- flaeche: N 11, Ausfälle 0 (0,00 %), davon ohne Ergebnis 0, Pflichtfehler 0
- territory: N 11, Ausfälle 0 (0,00 %), davon ohne Ergebnis 0, Pflichtfehler 0
- Nachspiel-Kontrolle am Archiv (§9 Nr. 4): bestanden; GNU Go ohne Vorgabe 10/10, Fuego 100 Spiele 10/10, Fuego 50 Spiele 10/10, alte PWA 10/10
    - bestätigt: Archivzugfolge in GNU Go regelkonform einspielbar; GNU Gos final_score der Schlussstellung gleich dem archivierten Endstand
    - nicht bestätigt: Dass die heutige Engine dieselben Züge wählen würde; Brett und Gefangene der Engine (prüft die Fortsetzung je Einheit)
- Wiederholbarkeit (§9 Nr. 7, nur Probe verlangt; Gegner gnugo und ki müssen gleich sein, fuego wird berichtet): fuego: 3/3 Einheiten erfüllt (je 1 Wiederholungsläufe, Einheiten 6), vollständige Läufe 3, davon gleich in Zugfolge und Stand 3 (versucht 3, unvollständig 0) (Gleichheit nur berichtet); gnugo: 2/2 Einheiten erfüllt (je 2 Wiederholungsläufe, Einheiten 2), vollständige Läufe 4, davon gleich in Zugfolge und Stand 4 (versucht 4, unvollständig 0); ki: 3/3 Einheiten erfüllt (je 1 Wiederholungsläufe, Einheiten 3), vollständige Läufe 3, davon gleich in Zugfolge und Stand 3 (versucht 3, unvollständig 0)
- KI-Züge in den Fortsetzungen (technisch): 11 reguläre, Steinzüge 3 bis 77 (Median 30), ohne KI-Steinzug: 0
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|206|341 (anfang): final_score "B+139.5", Fläche aus Tot-Liste 136.5, Unterschied -3, tote Steine 20
    - Bestandteile (unsere Zählung): Schwarz Steine 150 + Gebiet 100, Weiß Steine 70 + Gebiet 36, neutral 5, tote Steine S/W 1/19
    - Punktabweichungen: G19 (GNU Go gebiet-S, unser Besitzer neutral); H19 (GNU Go gebiet-S, unser Besitzer neutral); J19 (GNU Go gebiet-S, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Zählvergleich zweier Verfahren (kein Gültigkeitskriterium) alte PWA|m1.jsonl.gz|206|341 (wiederholung 2 anfang): final_score "B+139.5", Fläche aus Tot-Liste 136.5, Unterschied -3, tote Steine 20
    - Bestandteile (unsere Zählung): Schwarz Steine 150 + Gebiet 100, Weiß Steine 70 + Gebiet 36, neutral 5, tote Steine S/W 1/19
    - Punktabweichungen: G19 (GNU Go gebiet-S, unser Besitzer neutral); H19 (GNU Go gebiet-S, unser Besitzer neutral); J19 (GNU Go gebiet-S, unser Besitzer neutral)
    - Brett, tote Koordinaten und beide Zählwerte stehen in den Rohdaten (diagnose)
- Konvention von GNU Gos `captures` (in der Kalibrierung bestimmt, je Stellung angewendet; Anzahl Stellungen): {"gefangen-von":11}
- Stellungen mit ungleichen Gefangenenzahlen (dort würde ein vertauschter Zähler auffallen): 10 von 11
- Zählvergleich: Fläche aus Tot-Liste ≠ final_score bei 1 Stellung(en): alte PWA|m1.jsonl.gz|206|341 (Vergleich zweier Zählverfahren, nicht Teil der Gültigkeit)
- Dauer je Einheit: Mittel 5 s, Maximum 10 s, Summe 0.02 h

## Technische Ausfälle nach Art (Befehl und Fehlertext unverändert)

keine

## Ausfälle (einzeln, §9 Nr. 6)

flaeche: 0
territory: 0

**Probe: keine Wirkungsauswertung.** Siegwechsel, Punkt-Mittel und Intervalle werden nicht berichtet.
