# Passregel-Vergleich, Stufe A (Auslösung)

Reine Rechnung auf Archivdaten (Schalter 1 in diesem Prozess). Keine Partie, kein GNU Go.

Zeilen gelesen: 2760, ausgewertet: 2760; übersprungen: {}

| Gruppe | Partien | Einheiten (vor Deckel) | Einheiten | ausgelöst Fläche | ausgelöst Territory | ohne Auslösung Fläche | ohne Auslösung Territory |
|---|---:|---:|---:|---:|---:|---:|---:|
| GNU Go ohne Vorgabe | 960 | 2 | 2 | 2 | 2 | 958 | 958 |
| Fuego 100 Spiele | 480 | 45 | 3 | 44 | 43 | 436 | 437 |
| Fuego 50 Spiele | 960 | 317 | 3 | 317 | 301 | 643 | 659 |
| alte PWA | 360 | 199 | 3 | 198 | 174 | 162 | 186 |

### Aufschlüsselung nach KI-Farbe

| Gruppe | KI-Farbe | Partien | ausgelöst Fläche | ausgelöst Territory |
|---|---|---:|---:|---:|
| GNU Go ohne Vorgabe | Schwarz | 480 | 1 | 1 |
| GNU Go ohne Vorgabe | Weiß | 480 | 1 | 1 |
| Fuego 100 Spiele | Schwarz | 240 | 10 | 8 |
| Fuego 100 Spiele | Weiß | 240 | 34 | 35 |
| Fuego 50 Spiele | Schwarz | 480 | 104 | 97 |
| Fuego 50 Spiele | Weiß | 480 | 213 | 204 |
| alte PWA | Schwarz | 180 | 91 | 81 |
| alte PWA | Weiß | 180 | 107 | 93 |

### Werte an der Auslösung (aus Sicht der KI: mit Annahmen, nur Bewiesenes, Spanne, gemischter Anteil)

| Wertung | Auswahl | Einheiten | mit | nur | Spanne | gemischt |
|---|---|---:|---|---|---|---|
| flaeche | alle | 11 | 78,2 (Median 74,5; 37,5 bis 135,5) | 78,1 (Median 73,5; 35,5 bis 136,5) | 0,455 (max 2,000) | 0,055 (max 0,162) |
| flaeche | KI Schwarz | 5 | 71,3 (Median 74,5; 37,5 bis 103,5) | 70,9 (Median 73,5; 35,5 bis 103,5) | 0,800 (max 2,000) | 0,088 (max 0,158) |
| flaeche | KI Weiß | 6 | 84,0 (Median 81,5; 50,5 bis 135,5) | 84,2 (Median 81,5; 50,5 bis 136,5) | 0,167 (max 1,000) | 0,027 (max 0,162) |
| territory | alle | 11 | 71,1 (Median 72,5; 29,5 bis 118,5) | 71,0 (Median 72,5; 27,5 bis 119,5) | 0,455 (max 2,000) | 0,055 (max 0,162) |
| territory | KI Schwarz | 5 | 61,1 (Median 58,5; 29,5 bis 95,5) | 60,7 (Median 57,5; 27,5 bis 95,5) | 0,800 (max 2,000) | 0,088 (max 0,158) |
| territory | KI Weiß | 6 | 79,5 (Median 81,0; 50,5 bis 118,5) | 79,7 (Median 81,0; 50,5 bis 119,5) | 0,167 (max 1,000) | 0,027 (max 0,162) |

Geprüfte Stellungen (Gegnerpass, KI am Zug): 56345

| Grund | Fläche | Territory |
|---|---:|---:|
| ausgelöst | 561 | 520 |
| nicht ausgespielt | 20090 | 20093 |
| ungeklärte Gruppen (Spanne) | 32270 | 32433 |
| Vorsprung zu klein | 2850 | 3282 |

Einheiten nach Abzug der Duplikate: Fläche 11, Territory 11 (Einheiten gesamt 11). Duplikate (gleiche Zugfolge bis zur Stellung, nur einmal gezählt): 0.
Kriterium aus §8: mindestens 183 Auslösungen je Wertung bei K = 0: Fläche NICHT erreicht, Territory NICHT erreicht.

Pflichtprüfungen Stufe A: bestanden.
