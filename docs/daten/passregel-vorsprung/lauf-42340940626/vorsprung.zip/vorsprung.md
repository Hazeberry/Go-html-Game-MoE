# Passregel: Untersuchung der Vorsprungsprüfung (nur Rechnung)

Code des Hauptlaufs: Commit `7d57e2bf1826904be9c4e6f8a59164db632d032f`; SHA-256 der benutzten index.html: `d3bcb1cc54c56f0729cf80d36a462fd564a69ed4561fccbe2d42efba461fa69b`.
Parameter: {"passNachGegnerpass":1,"passMarge":20,"passSpanne":2,"passGemischt":0.25,"komi":7.5}. Quelle der Daten: Lauf 42331033107, Artefakt bericht 13557498693.
Referenzstand: Fläche = GNU Gos final_score, Territory = App-Rechnung mit GNU Gos Tot-Liste. Alles beschreibend, kein Urteil, keine Änderung am Spiel.

**Lauf gültig.** (Schritt 0 vollständig, Identitätskontrolle und Zugfolge bestanden.)

## flaeche

### Schritt 0: Datenprüfung

Einheiten: 561; mit allen Feldern: 561; nicht auswertbar: 0. Fehlende Felder: {"Ergebniszeile":0,"arm1":0,"diagnose.anfang":0,"brett":0,"gefangen":0,"tote":0,"pruef.mit":0,"pruef.nur":0,"zuege":0}.
Identitätskontrolle (neu gerechnetes mit/nur = gespeichert): bestanden 561, durchgefallen 0. Zugfolge ≠ diagnose.anfang: 0.

### Schritt 1: Kennzahlen

N 561, auswertbar 561; **V (Referenzstand < 0): 18** (3.21 %); Näherungsfälle (0 ≤ Referenzstand < 20): 1.
V je Gruppe: {"GNU Go ohne Vorgabe":{"N":2,"V":0},"Fuego 100 Spiele":{"N":44,"V":4},"Fuego 50 Spiele":{"N":317,"V":14},"alte PWA":{"N":198,"V":0}}; V je KI-Farbe: {"W":{"N":355,"V":10},"S":{"N":206,"V":8}}.
Referenzstand in V (aufsteigend): -62.5, -32.5, -32.5, -30.5, -28.5, -19.5, -18.5, -17.5, -17.5, -16.5, -13.5, -11.5, -11.5, -9.5, -5.5, -3.5, -2.5, -1.5.
D in V (aufsteigend): 24, 31, 32, 37, 44, 47, 52, 52, 57, 62, 65, 67, 72, 84, 86, 97, 104, 122.
D über alle auswertbaren Auslösungen: n 561, Mittel 1.59, Median 0, q10 0, q90 0, q99 72, Minimum -50, Maximum 122; D > 20: 22 (3.92 %). Nur Beschreibung, D > 20 ist kein Vorzeichenwechsel.
Zählabweichung (Fläche aus Tot-Liste ≠ final_score) bei 15 Einheit(en) dieser Wertung; davon in V: 1 (Fuego 50 Spiele|D.jsonl.gz|212|337).

### Schritt 2: Zerlegung von D in V (Rechenidentität)

Zerlegt: 18; nicht zerlegt: 0.


**Fuego 100 Spiele|f-D.jsonl.gz|21|428** (Fuego 100 Spiele, KI W): Vorschau (mit) 92.5, Referenzstand -11.5, D 104; Vorschau − Tot-Liste-Rechnung 104, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 90, Gebiet mit anderem Besitz 14 (7 Punkte).
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: B19
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: Q19 R19 S19 R18
- nur Tot-Liste tot, W, 17 Steine, Beitrag 34: A18 A17 B17 A16 C17 A15 C16 A14 B14 A13 B13 B12 C12 B11 C11 A11 D11
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: S17
- nur Tot-Liste tot, W, 20 Steine, Beitrag 40: Q7 Q6 P6 R6 Q5 P5 Q4 P4 R4 Q3 R3 Q2 S3 R2 P2 Q1 T3 R1 S1 T1
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: S5

**Fuego 100 Spiele|f-D.jsonl.gz|172|333** (Fuego 100 Spiele, KI S): Vorschau (mit) 39.5, Referenzstand -32.5, D 72; Vorschau − Tot-Liste-Rechnung 72, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 58, Gebiet mit anderem Besitz 14 (8 Punkte).
- nur Tot-Liste tot, S, 14 Steine, Beitrag 28: S19 S18 R18 S17 Q18 R17 T17 Q17 R16 T16 P17 T15 P16 T14
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: Q15
- nur Tot-Liste tot, S, 7 Steine, Beitrag 14: A4 A3 B3 C3 C2 C1 D1
- nur Tot-Liste tot, S, 4 Steine, Beitrag 8: G3 G2 G1 F1
- nur Vorschau tot, W, 1 Steine, Beitrag 2: A2
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: E2
- nur Vorschau tot, W, 1 Steine, Beitrag 2: B1

**Fuego 100 Spiele|f-D.jsonl.gz|175|344** (Fuego 100 Spiele, KI W): Vorschau (mit) 55.5, Referenzstand -9.5, D 65; Vorschau − Tot-Liste-Rechnung 65, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 50, Gebiet mit anderem Besitz 15 (13 Punkte).
- nur Tot-Liste tot, W, 20 Steine, Beitrag 40: T16 T15 S15 S14 S13 R13 T13 T12 T11 S11 T10 R11 S10 T9 R10 Q10 Q9 Q8 P8 Q7
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: O7
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: P6 P5 O5 N5

**Fuego 100 Spiele|f-D.jsonl.gz|480|319** (Fuego 100 Spiele, KI S): Vorschau (mit) 20.5, Referenzstand -16.5, D 37; Vorschau − Tot-Liste-Rechnung 37, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 26, Gebiet mit anderem Besitz 11 (9 Punkte).
- nur Tot-Liste tot, S, 5 Steine, Beitrag 10: P19 Q19 P18 O18 N18
- nur Tot-Liste tot, S, 8 Steine, Beitrag 16: S19 S18 R18 T18 T17 T16 S16 S15

**Fuego 50 Spiele|D.jsonl.gz|23|340** (Fuego 50 Spiele, KI W): Vorschau (mit) 29.5, Referenzstand -1.5, D 31; Vorschau − Tot-Liste-Rechnung 31, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 26, Gebiet mit anderem Besitz 5 (3 Punkte).
- nur Tot-Liste tot, W, 12 Steine, Beitrag 24: A14 B14 A13 C14 B13 C13 B12 B11 A11 B10 A10 B9
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: A8

**Fuego 50 Spiele|D.jsonl.gz|179|366** (Fuego 50 Spiele, KI W): Vorschau (nur) 44.5, Referenzstand -17.5, D 62; Vorschau − Tot-Liste-Rechnung 62, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 48, Gebiet mit anderem Besitz 14 (9 Punkte).
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: B19
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: D19 D18 C18 E18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: F19
- nur Tot-Liste tot, W, 10 Steine, Beitrag 20: P19 Q19 R19 R18 S18 R17 T18 Q17 T19 P17
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: R15 S15 T15 T14
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: Q14 Q13 R13 S13

**Fuego 50 Spiele|D.jsonl.gz|212|337** (Fuego 50 Spiele, KI S): Vorschau (mit) 36.5, Referenzstand -30.5, D 67; Vorschau − Tot-Liste-Rechnung 67, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 54, Gebiet mit anderem Besitz 13 (8 Punkte).
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: B19
- nur Tot-Liste tot, S, 15 Steine, Beitrag 30: D19 E19 F19 E18 G19 G18 H18 J18 H17 J17 K17 L17 M17 L18 L19
- nur Vorschau tot, W, 2 Steine, Beitrag 4: J19 K19
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: C18
- nur Tot-Liste tot, S, 6 Steine, Beitrag 12: B3 C3 B2 B1 A1 C1
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: D2
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: E1

**Fuego 50 Spiele|D.jsonl.gz|270|449** (Fuego 50 Spiele, KI S): Vorschau (mit) 89.5, Referenzstand -32.5, D 122; Vorschau − Tot-Liste-Rechnung 122, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 104, Gebiet mit anderem Besitz 18 (10 Punkte).
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: P19
- nur Tot-Liste tot, S, 8 Steine, Beitrag 16: R19 R18 Q18 S18 R17 T18 R16 T17
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: T15
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: S14
- nur Tot-Liste tot, S, 18 Steine, Beitrag 36: T13 T12 S12 T11 S11 S10 S9 R9 T9 S8 Q9 R8 T8 Q8 T7 Q7 T6 S6
- nur Tot-Liste tot, S, 22 Steine, Beitrag 44: O4 O3 N3 O2 N2 O1 M2 N1 P1 L2 Q1 K2 R1 Q2 J2 K3 K1 R2 J3 S2 R3 H3
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: T1

**Fuego 50 Spiele|D.jsonl.gz|390|357** (Fuego 50 Spiele, KI S): Vorschau (mit) 29.5, Referenzstand -2.5, D 32; Vorschau − Tot-Liste-Rechnung 32, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 26, Gebiet mit anderem Besitz 6 (3 Punkte).
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: A7
- nur Tot-Liste tot, S, 12 Steine, Beitrag 24: B6 B5 A5 C5 C4 C3 B3 D3 A3 A2 A1 B1

**Fuego 50 Spiele|D.jsonl.gz|401|346** (Fuego 50 Spiele, KI W): Vorschau (mit) 41.5, Referenzstand -5.5, D 47; Vorschau − Tot-Liste-Rechnung 47, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 34, Gebiet mit anderem Besitz 13 (9 Punkte).
- nur Tot-Liste tot, W, 5 Steine, Beitrag 10: B19 B18 C18 C17 D17
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: D19
- nur Tot-Liste tot, W, 8 Steine, Beitrag 16: Q19 R19 R18 S18 T18 S17 T19 T17
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: E18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: P18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: Q17

**Fuego 50 Spiele|D.jsonl.gz|523|354** (Fuego 50 Spiele, KI W): Vorschau (mit) 66.5, Referenzstand -17.5, D 84; Vorschau − Tot-Liste-Rechnung 84, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 64, Gebiet mit anderem Besitz 20 (10 Punkte).
- nur Vorschau tot, S, 6 Steine, Beitrag 12: N19 N18 O18 O17 O16 O15
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: R19
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T19
- nur Vorschau tot, S, 17 Steine, Beitrag 34: Q18 R18 Q17 Q16 Q15 R15 Q14 R14 P14 S14 P13 T14 O13 P12 T15 Q12 Q11
- nur Tot-Liste tot, W, 7 Steine, Beitrag 14: S18 S17 R17 S16 R16 T16 S15

**Fuego 50 Spiele|D.jsonl.gz|533|354** (Fuego 50 Spiele, KI W): Vorschau (mit) 20.5, Referenzstand -3.5, D 24; Vorschau − Tot-Liste-Rechnung 24, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 12, Gebiet mit anderem Besitz 12 (9 Punkte).
- nur Tot-Liste tot, W, 5 Steine, Beitrag 10: C19 C18 B18 D18 A18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: E19

**Fuego 50 Spiele|D.jsonl.gz|566|379** (Fuego 50 Spiele, KI S): Vorschau (mit) 25.5, Referenzstand -18.5, D 44; Vorschau − Tot-Liste-Rechnung 44, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 32, Gebiet mit anderem Besitz 12 (7 Punkte).
- nur Tot-Liste tot, S, 5 Steine, Beitrag 10: N19 O19 P19 O18 Q19
- nur Tot-Liste tot, S, 5 Steine, Beitrag 10: S19 S18 R18 S17 T17
- nur Tot-Liste tot, S, 4 Steine, Beitrag 8: R3 S3 T3 S2
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: R1
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: T1

**Fuego 50 Spiele|D.jsonl.gz|599|330** (Fuego 50 Spiele, KI W): Vorschau (mit) 32.5, Referenzstand -19.5, D 52; Vorschau − Tot-Liste-Rechnung 52, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 26, Gebiet mit anderem Besitz 26 (24 Punkte).
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: C19
- nur Tot-Liste tot, W, 11 Steine, Beitrag 22: E19 E18 D18 F18 E17 G18 H18 G17 H17 J17 H16
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: F16

**Fuego 50 Spiele|D.jsonl.gz|622|307** (Fuego 50 Spiele, KI S): Vorschau (mit) 34.5, Referenzstand -62.5, D 97; Vorschau − Tot-Liste-Rechnung 97, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 88, Gebiet mit anderem Besitz 9 (5 Punkte).
- nur Tot-Liste tot, S, 15 Steine, Beitrag 30: D12 E12 D11 C11 D10 D9 E9 E8 F8 F7 G7 G6 G5 G4 H4
- nur Vorschau tot, W, 11 Steine, Beitrag 22: F12 F11 F10 F9 G9 G8 H8 J8 H7 H6 H5
- nur Tot-Liste tot, S, 18 Steine, Beitrag 36: J7 J6 K6 J5 L6 L5 M5 L4 M4 N4 M3 O4 P4 P5 P6 O6 Q6 N6

**Fuego 50 Spiele|D.jsonl.gz|808|403** (Fuego 50 Spiele, KI S): Vorschau (mit) 28.5, Referenzstand -28.5, D 57; Vorschau − Tot-Liste-Rechnung 57, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 42, Gebiet mit anderem Besitz 15 (11 Punkte).
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: N19
- nur Tot-Liste tot, S, 11 Steine, Beitrag 22: P19 Q19 R19 Q18 R18 S18 R17 T18 S17 T19 T17
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: O18
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: S5
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: R4
- nur Tot-Liste tot, S, 6 Steine, Beitrag 12: T4 T3 S3 T2 S2 S1

**Fuego 50 Spiele|D.jsonl.gz|889|372** (Fuego 50 Spiele, KI W): Vorschau (mit) 72.5, Referenzstand -13.5, D 86; Vorschau − Tot-Liste-Rechnung 86, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 56, Gebiet mit anderem Besitz 30 (19 Punkte).
- nur Tot-Liste tot, W, 9 Steine, Beitrag 18: T10 T9 T8 T7 S7 R7 S6 R8 R9
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: Q6 Q5 R5 R4
- nur Vorschau tot, S, 3 Steine, Beitrag 6: S5 S4 S3
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T5
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: N4 O4 P4 P3
- nur Vorschau tot, S, 7 Steine, Beitrag 14: Q4 Q3 Q2 P2 R2 P1 O1

**Fuego 50 Spiele|D.jsonl.gz|903|306** (Fuego 50 Spiele, KI W): Vorschau (nur) 40.5, Referenzstand -11.5, D 52; Vorschau − Tot-Liste-Rechnung 52, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 28, Gebiet mit anderem Besitz 24 (22 Punkte).
- nur Tot-Liste tot, W, 2 Steine, Beitrag 4: J9 J8
- nur Tot-Liste tot, W, 2 Steine, Beitrag 4: N9 O9
- nur Tot-Liste tot, W, 8 Steine, Beitrag 16: Q3 R3 Q2 R2 S2 R1 S1 T1
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T3
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: P1

## territory

### Schritt 0: Datenprüfung

Einheiten: 520; mit allen Feldern: 520; nicht auswertbar: 0. Fehlende Felder: {"Ergebniszeile":0,"arm1":0,"diagnose.anfang":0,"brett":0,"gefangen":0,"tote":0,"pruef.mit":0,"pruef.nur":0,"zuege":0}.
Identitätskontrolle (neu gerechnetes mit/nur = gespeichert): bestanden 520, durchgefallen 0. Zugfolge ≠ diagnose.anfang: 0.

### Schritt 1: Kennzahlen

N 520, auswertbar 520; **V (Referenzstand < 0): 11** (2.12 %); Näherungsfälle (0 ≤ Referenzstand < 20): 0.
V je Gruppe: {"GNU Go ohne Vorgabe":{"N":2,"V":0},"Fuego 100 Spiele":{"N":43,"V":3},"Fuego 50 Spiele":{"N":301,"V":8},"alte PWA":{"N":174,"V":0}}; V je KI-Farbe: {"W":{"N":333,"V":7},"S":{"N":187,"V":4}}.
Referenzstand in V (aufsteigend): -94.5, -76.5, -65.5, -46.5, -44.5, -39.5, -36.5, -35.5, -30.5, -25.5, -22.5.
D in V (aufsteigend): 47, 52, 62, 65, 67, 72, 84, 86, 97, 104, 122.
D über alle auswertbaren Auslösungen: n 520, Mittel 1.16, Median 0, q10 0, q90 0, q99 72, Minimum -50, Maximum 122; D > 20: 14 (2.69 %). Nur Beschreibung, D > 20 ist kein Vorzeichenwechsel.
Zählabweichung (Fläche aus Tot-Liste ≠ final_score) bei 14 Einheit(en) dieser Wertung; davon in V: 1 (Fuego 50 Spiele|D.jsonl.gz|212|337).

### Schritt 2: Zerlegung von D in V (Rechenidentität)

Zerlegt: 11; nicht zerlegt: 0.


**Fuego 100 Spiele|f-D.jsonl.gz|21|428** (Fuego 100 Spiele, KI W): Vorschau (mit) 38.5, Referenzstand -65.5, D 104; Vorschau − Tot-Liste-Rechnung 104, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 90, Gebiet mit anderem Besitz 14 (7 Punkte).
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: B19
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: Q19 R19 S19 R18
- nur Tot-Liste tot, W, 17 Steine, Beitrag 34: A18 A17 B17 A16 C17 A15 C16 A14 B14 A13 B13 B12 C12 B11 C11 A11 D11
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: S17
- nur Tot-Liste tot, W, 20 Steine, Beitrag 40: Q7 Q6 P6 R6 Q5 P5 Q4 P4 R4 Q3 R3 Q2 S3 R2 P2 Q1 T3 R1 S1 T1
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: S5

**Fuego 100 Spiele|f-D.jsonl.gz|172|333** (Fuego 100 Spiele, KI S): Vorschau (mit) 25.5, Referenzstand -46.5, D 72; Vorschau − Tot-Liste-Rechnung 72, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 58, Gebiet mit anderem Besitz 14 (8 Punkte).
- nur Tot-Liste tot, S, 14 Steine, Beitrag 28: S19 S18 R18 S17 Q18 R17 T17 Q17 R16 T16 P17 T15 P16 T14
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: Q15
- nur Tot-Liste tot, S, 7 Steine, Beitrag 14: A4 A3 B3 C3 C2 C1 D1
- nur Tot-Liste tot, S, 4 Steine, Beitrag 8: G3 G2 G1 F1
- nur Vorschau tot, W, 1 Steine, Beitrag 2: A2
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: E2
- nur Vorschau tot, W, 1 Steine, Beitrag 2: B1

**Fuego 100 Spiele|f-D.jsonl.gz|175|344** (Fuego 100 Spiele, KI W): Vorschau (mit) 34.5, Referenzstand -30.5, D 65; Vorschau − Tot-Liste-Rechnung 65, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 50, Gebiet mit anderem Besitz 15 (13 Punkte).
- nur Tot-Liste tot, W, 20 Steine, Beitrag 40: T16 T15 S15 S14 S13 R13 T13 T12 T11 S11 T10 R11 S10 T9 R10 Q10 Q9 Q8 P8 Q7
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: O7
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: P6 P5 O5 N5

**Fuego 50 Spiele|D.jsonl.gz|179|366** (Fuego 50 Spiele, KI W): Vorschau (nur) 22.5, Referenzstand -39.5, D 62; Vorschau − Tot-Liste-Rechnung 62, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 48, Gebiet mit anderem Besitz 14 (9 Punkte).
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: B19
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: D19 D18 C18 E18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: F19
- nur Tot-Liste tot, W, 10 Steine, Beitrag 20: P19 Q19 R19 R18 S18 R17 T18 Q17 T19 P17
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: R15 S15 T15 T14
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: Q14 Q13 R13 S13

**Fuego 50 Spiele|D.jsonl.gz|212|337** (Fuego 50 Spiele, KI S): Vorschau (mit) 30.5, Referenzstand -36.5, D 67; Vorschau − Tot-Liste-Rechnung 67, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 54, Gebiet mit anderem Besitz 13 (8 Punkte).
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: B19
- nur Tot-Liste tot, S, 15 Steine, Beitrag 30: D19 E19 F19 E18 G19 G18 H18 J18 H17 J17 K17 L17 M17 L18 L19
- nur Vorschau tot, W, 2 Steine, Beitrag 4: J19 K19
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: C18
- nur Tot-Liste tot, S, 6 Steine, Beitrag 12: B3 C3 B2 B1 A1 C1
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: D2
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: E1

**Fuego 50 Spiele|D.jsonl.gz|270|449** (Fuego 50 Spiele, KI S): Vorschau (mit) 27.5, Referenzstand -94.5, D 122; Vorschau − Tot-Liste-Rechnung 122, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 104, Gebiet mit anderem Besitz 18 (10 Punkte).
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: P19
- nur Tot-Liste tot, S, 8 Steine, Beitrag 16: R19 R18 Q18 S18 R17 T18 R16 T17
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: T15
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: S14
- nur Tot-Liste tot, S, 18 Steine, Beitrag 36: T13 T12 S12 T11 S11 S10 S9 R9 T9 S8 Q9 R8 T8 Q8 T7 Q7 T6 S6
- nur Tot-Liste tot, S, 22 Steine, Beitrag 44: O4 O3 N3 O2 N2 O1 M2 N1 P1 L2 Q1 K2 R1 Q2 J2 K3 K1 R2 J3 S2 R3 H3
- nur Tot-Liste tot, S, 1 Steine, Beitrag 2: T1

**Fuego 50 Spiele|D.jsonl.gz|401|346** (Fuego 50 Spiele, KI W): Vorschau (mit) 21.5, Referenzstand -25.5, D 47; Vorschau − Tot-Liste-Rechnung 47, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 34, Gebiet mit anderem Besitz 13 (9 Punkte).
- nur Tot-Liste tot, W, 5 Steine, Beitrag 10: B19 B18 C18 C17 D17
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: D19
- nur Tot-Liste tot, W, 8 Steine, Beitrag 16: Q19 R19 R18 S18 T18 S17 T19 T17
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: E18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: P18
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: Q17

**Fuego 50 Spiele|D.jsonl.gz|523|354** (Fuego 50 Spiele, KI W): Vorschau (mit) 48.5, Referenzstand -35.5, D 84; Vorschau − Tot-Liste-Rechnung 84, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 64, Gebiet mit anderem Besitz 20 (10 Punkte).
- nur Vorschau tot, S, 6 Steine, Beitrag 12: N19 N18 O18 O17 O16 O15
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: R19
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T19
- nur Vorschau tot, S, 17 Steine, Beitrag 34: Q18 R18 Q17 Q16 Q15 R15 Q14 R14 P14 S14 P13 T14 O13 P12 T15 Q12 Q11
- nur Tot-Liste tot, W, 7 Steine, Beitrag 14: S18 S17 R17 S16 R16 T16 S15

**Fuego 50 Spiele|D.jsonl.gz|622|307** (Fuego 50 Spiele, KI S): Vorschau (mit) 20.5, Referenzstand -76.5, D 97; Vorschau − Tot-Liste-Rechnung 97, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 88, Gebiet mit anderem Besitz 9 (5 Punkte).
- nur Tot-Liste tot, S, 15 Steine, Beitrag 30: D12 E12 D11 C11 D10 D9 E9 E8 F8 F7 G7 G6 G5 G4 H4
- nur Vorschau tot, W, 11 Steine, Beitrag 22: F12 F11 F10 F9 G9 G8 H8 J8 H7 H6 H5
- nur Tot-Liste tot, S, 18 Steine, Beitrag 36: J7 J6 K6 J5 L6 L5 M5 L4 M4 N4 M3 O4 P4 P5 P6 O6 Q6 N6

**Fuego 50 Spiele|D.jsonl.gz|889|372** (Fuego 50 Spiele, KI W): Vorschau (mit) 41.5, Referenzstand -44.5, D 86; Vorschau − Tot-Liste-Rechnung 86, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 56, Gebiet mit anderem Besitz 30 (19 Punkte).
- nur Tot-Liste tot, W, 9 Steine, Beitrag 18: T10 T9 T8 T7 S7 R7 S6 R8 R9
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: Q6 Q5 R5 R4
- nur Vorschau tot, S, 3 Steine, Beitrag 6: S5 S4 S3
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T5
- nur Tot-Liste tot, W, 4 Steine, Beitrag 8: N4 O4 P4 P3
- nur Vorschau tot, S, 7 Steine, Beitrag 14: Q4 Q3 Q2 P2 R2 P1 O1

**Fuego 50 Spiele|D.jsonl.gz|903|306** (Fuego 50 Spiele, KI W): Vorschau (nur) 29.5, Referenzstand -22.5, D 52; Vorschau − Tot-Liste-Rechnung 52, Rest Tot-Liste-Rechnung − Referenzstand 0.
Beiträge: Steine mit verschiedenem Urteil 28, Gebiet mit anderem Besitz 24 (22 Punkte).
- nur Tot-Liste tot, W, 2 Steine, Beitrag 4: J9 J8
- nur Tot-Liste tot, W, 2 Steine, Beitrag 4: N9 O9
- nur Tot-Liste tot, W, 8 Steine, Beitrag 16: Q3 R3 Q2 R2 S2 R1 S1 T1
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: T3
- nur Tot-Liste tot, W, 1 Steine, Beitrag 2: P1

## Überlappung

V in Fläche und in Territory: 11 (Fuego 100 Spiele|f-D.jsonl.gz|21|428, Fuego 100 Spiele|f-D.jsonl.gz|172|333, Fuego 100 Spiele|f-D.jsonl.gz|175|344, Fuego 50 Spiele|D.jsonl.gz|179|366, Fuego 50 Spiele|D.jsonl.gz|212|337, Fuego 50 Spiele|D.jsonl.gz|270|449, Fuego 50 Spiele|D.jsonl.gz|401|346, Fuego 50 Spiele|D.jsonl.gz|523|354, Fuego 50 Spiele|D.jsonl.gz|622|307, Fuego 50 Spiele|D.jsonl.gz|889|372, Fuego 50 Spiele|D.jsonl.gz|903|306).

**Grenzen.** Die Zerlegung nennt Beiträge, keine Ursache im Programm. Eine „große, unterschiedlich bewertete Gruppe“ gilt nur dort, wo die Zerlegung sie als Beitrag ausweist. Keine Änderung an Schwellen oder am Spiel.
