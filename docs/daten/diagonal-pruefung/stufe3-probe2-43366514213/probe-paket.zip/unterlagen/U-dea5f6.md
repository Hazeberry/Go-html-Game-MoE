# Unterlage U-dea5f6

Beurteile die mit `@` markierte Kette: Ist sie lebendig, tot, in Seki, vom Ko oder vom Zug abhängig, oder nicht entscheidbar? Die Anleitung steht in `anleitung-beurteiler.md`.

- **Markierte Kette:** Schwarz, 3 Steine: B4 B3 B2
- **Stellung:** nach Zug 251 (Zählung ab 1, Pässe eingerechnet); die Partie ist nicht beendet
- **Als Nächstes am Zug wäre:** Weiß
- **Regeln:** chinesisch (Flächenzählung), Komi 7,5
- **Gefangene:** Schwarz hat 14 Steine geschlagen, Weiß 11
- **Pässe am Ende:** keine
- **Ko-Punkt (sofortiges Zurücknehmen verboten):** keiner
- **Letzte 10 Züge:** 242. Weiß pass; 243. Schwarz L8; 244. Weiß pass; 245. Schwarz D6; 246. Weiß E4; 247. Schwarz B4; 248. Weiß C2; 249. Schwarz B2; 250. Weiß C3; 251. Schwarz B3

## Brett

```
    A B C D E F G H J K L M N O P Q R S T
19  . . . . X . . O X X X . . . . . . X X  19
18  . . . X O O O O O X . X . . X . X X X  18
17  O O O O X O . X O X . X . X . X X O X  17
16  X X X . X O . X O O X . . . X O O O O  16
15  X O X X X X O O X X X . . . X O O O .  15
14  O O X O X O O X X . . . . X . X O . O  14
13  . O X O X . O X . . . X . . X . X O .  13
12  . . O O O O O O X . . . . . X X X O O  12
11  . O . O . . O X X . . . . . . . X X O  11
10  . X O . O O X . X . X . X . . . X . X  10
 9  . X O . O X . X . . . . . . . X . . .   9
 8  . X O O X X X X X X X . X . . . X X X   8
 7  . O O . O X O O O O X X . X X . . . .   7
 6  . . . X O X O O . O O O X X O X X X .   6
 5  . . . O . O . O . . . . O X O O O X .   5
 4  . @ . O O . O . . . O O O O O . O X X   4
 3  . @ O . O . . O O O X X X X O O X X X   3
 2  . @ O . . O O X X X X O O O O X X . .   2
 1  . . . . . . X . X . . . . . O O X . .   1
    A B C D E F G H J K L M N O P Q R S T
```

`X` Schwarz, `O` Weiß, `.` leer, `@` markierte Kette.

## Zuggeschichte (SGF, alle Züge bis zur Stellung)

```
(;GM[1]FF[4]CA[UTF-8]SZ[19]KM[7.5]RU[Chinese]PB[Schwarz]PW[Weiss]
;B[qc];W[dp];B[qi];W[cc];B[kd];W[qp];B[kj];W[ic];B[jb];W[oq]
;B[qn];W[oo];B[nn];W[on];B[om];W[pd];B[oe];W[qd];B[pc];W[qf]
;B[od];W[ib];B[hd];W[id];B[ie];W[gb];B[ec];W[eb];B[db];W[fc]
;B[ed];W[dc];B[gl];W[fd];B[fe];W[ee];B[ef];W[ge];B[de];W[gf]
;B[hg];W[gg];B[gh];W[fh];B[fi];W[eh];B[ei];W[dg];B[ro];W[lp]
;B[no];W[pg];B[oh];W[rc];B[rb];W[rd];B[rp];W[of];B[nf];W[kc]
;B[lc];W[hh];B[ih];W[gi];B[hi];W[gh];B[gj];W[iq];B[hr];W[di]
;B[dj];W[kb];B[ci];W[dh];B[lb];W[bf];B[qq];W[np];B[pr];W[cj]
;B[bj];W[ck];B[dk];W[bi];B[bk];W[cl];B[bl];W[dl];B[el];W[mo]
;B[mn];W[ln];B[lm];W[kn];B[km];W[hj];B[ii];W[jn];B[jc];W[cm]
;B[hk];W[bm];B[ka];W[pe];B[og];W[he];B[if];W[rh];B[ri];W[si]
;B[sj];W[sh];B[pf];W[rj];B[qj];W[rk];B[qg];W[rg];B[ph];W[sb]
;B[qb];W[qk];B[pk];W[jm];B[jl];W[mm];B[nm];W[gn];B[ml];W[em]
;B[fm];W[en];B[fn];W[fj];B[ij];W[ek];B[rf];W[qe];B[qh];W[sk]
;B[ql];W[sf];B[rl];W[or];B[ir];W[jq];B[jr];W[fr];B[go];W[eq]
;B[sl];W[hq];B[sj];W[re];B[fk];W[ej];B[fl];W[pq];B[qr];W[hn]
;B[eo];W[do];B[ra];W[ps];B[qs];W[os];B[sa];W[qo];B[pn];W[po]
;B[sc];W[im];B[il];W[jd];B[je];W[ho];B[hf];W[gp];B[ia];W[ha]
;B[ja];W[fo];B[hc];W[hb];B[ea];W[fb];B[ce];W[be];B[bd];W[bc]
;B[cd];W[ac];B[ad];W[sd];B[sb];W[oc];B[ob];W[hm];B[hl];W[gm]
;B[nc];W[];B[ae];W[af];B[cf];W[bg];B[cg];W[ch];B[eg];W[df]
;B[ee];W[ff];B[kr];W[mr];B[kq];W[kp];B[lq];W[gr];B[mq];W[mp]
;B[nq];W[hs];B[is];W[nr];B[gs];W[lr];B[ke];W[];B[lg];W[]
;B[pp];W[op];B[rn];W[];B[rq];W[];B[sq];W[];B[sp];W[]
;B[mj];W[];B[kl];W[];B[dn];W[ep];B[bp];W[cr];B[br];W[cq]
;B[bq])
```
