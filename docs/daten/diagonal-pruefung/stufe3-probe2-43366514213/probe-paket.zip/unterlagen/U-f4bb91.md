# Unterlage U-f4bb91

Beurteile die mit `@` markierte Kette: Ist sie lebendig, tot, in Seki, vom Ko oder vom Zug abhängig, oder nicht entscheidbar? Die Anleitung steht in `anleitung-beurteiler.md`.

- **Markierte Kette:** Schwarz, 8 Steine: R13 Q12 R12 S12 Q11 P10 Q10 Q9
- **Stellung:** nach Zug 251 (Zählung ab 1, Pässe eingerechnet); die Partie ist nicht beendet
- **Als Nächstes am Zug wäre:** Weiß
- **Regeln:** chinesisch (Flächenzählung), Komi 7,5
- **Gefangene:** Schwarz hat 11 Steine geschlagen, Weiß 26
- **Pässe am Ende:** keine
- **Ko-Punkt (sofortiges Zurücknehmen verboten):** keiner
- **Letzte 10 Züge:** 242. Weiß J1; 243. Schwarz K2; 244. Weiß K4; 245. Schwarz S5; 246. Weiß D7; 247. Schwarz D8; 248. Weiß E7; 249. Schwarz C7; 250. Weiß D6; 251. Schwarz S4

## Brett

```
    A B C D E F G H J K L M N O P Q R S T
19  . . . . . . O . O X . . . . . O O O .  19
18  . . . . . O X O . O O . . . O . O X O  18
17  . . . . . O X X O O O . . O O O X X X  17
16  . . . O . O O X X O . O . . X O . X O  16
15  . . . . . O O O X X O O X . X O O X .  15
14  O O O . O X O O X X O X X X . X O X .  14
13  O . O O X X X X X . X O O O X . @ O .  13
12  . O O X . . . . . . X O . . O @ @ @ .  12
11  O O X X . . . . . . X O O . O @ O . .  11
10  X X . . . . . . . . . X O O @ @ O . .  10
 9  . . . . . . . . . . X . X O O @ O . .   9
 8  . . X X X . . . . . X X X X O O . O .   8
 7  X X X O O X X X . X . X O X X O O . O   7
 6  X O O O . O O O X X X O O O X O O O O   6
 5  O O . O O X . O O O O O O O O O O X O   5
 4  . . . O X . X . . O . X X O O O X X X   4
 3  . O O X . X . O O X . X . X X X X X X   3
 2  . O X . X . X O X X X . . . . . . . .   2
 1  . X . . . . X O O X . . . . . . . . .   1
    A B C D E F G H J K L M N O P Q R S T
```

`X` Schwarz, `O` Weiß, `.` leer, `@` markierte Kette.

## Zuggeschichte (SGF, alle Züge bis zur Stellung)

```
(;GM[1]FF[4]CA[UTF-8]SZ[19]KM[7.5]RU[Chinese]PB[Schwarz]PW[Weiss]
;B[qq];W[dp];B[ql];W[dd];B[lq];W[pd];B[kk];W[qf];B[ph];W[nc]
;B[gp];W[cn];B[el];W[qo];B[po];W[pn];B[on];W[pm];B[om];W[pl]
;B[pk];W[ol];B[nl];W[ok];B[oj];W[nk];B[mk];W[nj];B[ni];W[mj]
;B[lj];W[mi];B[mh];W[li];B[ki];W[lh];B[kh];W[lg];B[kg];W[kf]
;B[lf];W[mg];B[nh];W[ng];B[og];W[of];B[jf];W[ke];B[je];W[jd]
;B[kd];W[le];B[me];W[ld];B[mf];W[kc];B[id];W[ic];B[hc];W[hb]
;B[ib];W[jc];B[hd];W[ia];B[ja];W[jb];B[eg];W[fc];B[gb];W[fb]
;B[er];W[ga];B[gc];W[fd];B[ge];W[fe];B[ff];W[gf];B[gg];W[hf]
;B[hg];W[he];B[qn];W[qm];B[rm];W[rn];B[nf];W[qn];B[qp];W[pp]
;B[ro];W[oo];B[no];W[np];B[oe];W[pe];B[sn];W[po];B[pq];W[op]
;B[mp];W[mo];B[mn];W[nn];B[nm];W[mm];B[no];W[lo];B[nq];W[nn]
;B[ml];W[ln];B[lm];W[km];B[mn];W[no];B[oq];W[mm];B[ll];W[rl]
;B[pf];W[qk];B[pj];W[qj];B[qg];W[rg];B[kn];W[ko];B[jn];W[jo]
;B[jm];W[io];B[rf];W[qe];B[rh];W[qi];B[qh];W[oi];B[pi];W[oh]
;B[hm];W[kb];B[cl];W[cf];B[ci];W[ef];B[fg];W[dg];B[dh];W[ch]
;B[bh];W[cg];B[bg];W[bf];B[di];W[ag];B[ah];W[af];B[ir];W[jr]
;B[jq];W[iq];B[kr];W[hr];B[js];W[hq];B[if];W[gd];B[ie];W[ge]
;B[ig];W[bi];B[bj];W[ai];B[aj];W[bh];B[bm];W[bn];B[an];W[ao]
;B[am];W[bo];B[od];W[oc];B[re];W[pc];B[rd];W[rc];B[sc];W[sb]
;B[rb];W[sd];B[qc];W[qb];B[sc];W[ra];B[sa];W[qa];B[pb];W[sb]
;B[rc];W[ob];B[sa];W[pa];B[lp];W[sb];B[mn];W[rp];B[rq];W[so]
;B[sq];W[mm];B[kl];W[mn];B[sp];W[sm];B[ro];W[sn];B[en];W[eo]
;B[fo];W[fn];B[fm];W[gn];B[gm];W[hn];B[in];W[ho];B[ep];W[do]
;B[dq];W[cq];B[cr];W[br];B[bs];W[bq];B[fq];W[rp];B[gr];W[hs]
;B[gs];W[is];B[jr];W[jp];B[ro];W[dm];B[dl];W[em];B[cm];W[dn]
;B[rp])
```
