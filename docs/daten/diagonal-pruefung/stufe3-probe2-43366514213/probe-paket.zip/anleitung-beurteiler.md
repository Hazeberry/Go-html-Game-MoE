# Anleitung für die Beurteilung

Du bekommst eine Reihe von Unterlagen (`unterlagen/U-….md`, dazu je eine SGF-Datei). In jeder Unterlage ist **eine Kette** von Steinen mit `@` markiert. Beurteile **jede Unterlage einzeln und unabhängig**, nur nach den Regeln des Go und nach dem, was auf dem Brett und in der Zuggeschichte steht.

## Aufgabe

Beurteile, ob die markierte Kette bei bestem Spiel beider Seiten (chinesische Regeln, Flächenzählung) **bestehen bleibt oder gefangen wird**. Die Stellung kann beendet oder mitten in der Partie sein; die Unterlage sagt es. Beurteile die Stellung, wie sie auf dem Brett steht, nicht, was im weiteren Verlauf der Partie vermutlich geschehen wäre.

## Kategorien (genau eine je Unterlage)

- `lebendig`: Die Kette bleibt bestehen (zwei echte Augen, ausreichende Freiheiten im Kampf oder Verbindung mit einer lebenden Gruppe), auch wenn die Gegenseite zuerst zieht.
- `tot`: Die Kette wird gefangen, auch wenn die eigene Seite zuerst zieht.
- `seki`: Beide Seiten können die Kette bzw. die gegnerische Gruppe nicht fangen; beide bleiben bestehen, ohne Gebiet.
- `ko_zugabhaengig`: Das Ergebnis ist bei Zug von Schwarz **ein anderes** als bei Zug von Weiß (wegen eines Kos oder weil der erste Zug am entscheidenden Punkt entscheidet). Gib dann **zusätzlich** das Urteil bei Zug von Schwarz (`urteilSchwarzAmZug`) und bei Zug von Weiß (`urteilWeissAmZug`) an, jeweils `lebendig`, `tot`, `seki` oder `nicht_entscheidbar`. Die beiden Teilurteile müssen sich unterscheiden.
- `nicht_entscheidbar`: Du kannst es nach sorgfältigem Lesen nicht entscheiden. Das ist eine ehrliche Antwort und besser als Raten.

## Zugrecht

Die Unterlage nennt, wer als Nächstes am Zug wäre. **Dein Urteil gilt trotzdem für beide Fälle:** Lies die Stellung einmal mit Schwarz am Zug und einmal mit Weiß am Zug.

- Kommst du in beiden Fällen zum selben Ergebnis, trage dieses Ergebnis als Kategorie ein (`lebendig`, `tot`, `seki` oder `nicht_entscheidbar`), **nicht** `ko_zugabhaengig`.
- Kommst du zu verschiedenen Ergebnissen, trage `ko_zugabhaengig` mit beiden Teilurteilen ein. Trage nie nur das Urteil für die Seite ein, die laut Unterlage am Zug ist.
- Das angegebene Zugrecht brauchst du für das Ko-Verbot: Der genannte Ko-Punkt ist nur für die Seite gesperrt, die laut Unterlage am Zug ist, und nur für ihren nächsten Zug. Liest du den anderen Fall (die andere Seite zieht zuerst), gilt am Anfang kein Ko-Verbot.

## Ko

Für jedes Ko gilt eine feste Annahme: **Keine Seite hat Ko-Drohungen außerhalb des Kampfes um die markierte Kette.** Wer nicht sofort zurückschlagen darf, kann also nur am Ort weiterspielen oder passen; danach darf die Gegenseite das Ko beenden. Du zählst keine Ko-Drohungen auf dem übrigen Brett.

Daraus folgt:

- **Ko, das nur eine Seite beenden kann** (die andere könnte nur immer wieder zurückschlagen, das Ko aber nie auflösen): Das Ergebnis ist für beide Zugrechte dasselbe. Trage es direkt ein, also `tot`, wenn die Kette am Ende fällt, und `lebendig`, wenn sie am Ende steht. Nenne das Ko in der Begründung.
- **Ko, das beide Seiten beenden können:** Wer es zuerst schlagen darf, gewinnt es. Meist sind die Ergebnisse dann verschieden, und die Kategorie ist `ko_zugabhaengig` mit beiden Teilurteilen.
- **Doppel-Ko und mehrstufiges Ko** liest du mit derselben Annahme zu Ende; ein Doppel-Ko kann eine Kette sicher leben lassen oder sicher fallen lassen.
- **Superko:** Du prüfst nicht, ob sich eine Stellung aus der Zuggeschichte wiederholt. Entsteht in deiner Lesung ein Kreislauf, den nur ein Wiederholungsverbot über mehrere Züge auflöst (zum Beispiel ein Dreifach-Ko), trage `nicht_entscheidbar` ein und nenne den Kreislauf.

## Lesetiefe

- Lies den **Kampf um die markierte Kette bis zum Ergebnis**: Die Kette ist geschlagen, sie hat zwei echte Augen oder eine nicht trennbare Verbindung zu einer Gruppe mit zwei echten Augen, es ist Seki, oder es bleibt ein Ko (siehe oben). Zum Kampf gehören alle Ketten und leeren Punkte, von denen das Schicksal der markierten Kette abhängt; das kann eine große Gruppe sein.
- **Nicht verlangt** sind: Ko-Drohungen auf dem übrigen Brett, Superko gegen die Zuggeschichte, der Punktestand, die Frage, wer die Partie gewinnt, und die Frage, ob sich ein Zug für eine Seite insgesamt lohnt. Was nicht verlangt ist, mindert die Sicherheit nicht und gehört nicht unter `offen`.
- Es gibt **keine Zeitvorgabe** je Unterlage. Kommst du nach sorgfältigem Lesen nicht zu einem Ergebnis, ist `nicht_entscheidbar` die richtige Antwort.

## Begründung und Sicherheit

Schreibe zu jeder Unterlage eine **Begründung** nach allgemeinen Go-Kriterien: echte und falsche Augen, Freiheiten, Verbindungen und Schnittpunkte, Randlage und Ecke, Seki, Ko, Lesen der entscheidenden Zugfolge. Nenne die Koordinaten der entscheidenden Punkte. Gib die **Sicherheit** an:

- `sicher`: Du hast den Kampf um die Kette in allen Varianten bis zum Ergebnis gelesen und siehst keine Alternative.
- `eher_sicher`: Du hältst das Urteil für richtig, hast aber nicht jede Variante des Kampfes zu Ende gelesen.
- `unsicher`: Du bist dir nicht sicher. Dann schreibe unter `offen`, was offen bleibt.

Bei `eher_sicher`, `unsicher` und `nicht_entscheidbar` ist `offen` Pflicht.

## Hilfsmittel

- **Erlaubt** sind Skripte, die du in dieser Arbeit selbst schreibst und die nur mechanisch arbeiten: SGF nachspielen, Brett anzeigen, Freiheiten zählen, prüfen, ob ein Zug erlaubt ist, eine von dir gewählte Zugfolge durchspielen. Das Urteil und die entscheidende Zugfolge kommen von dir; ein Skript prüft sie nach, es sucht sie nicht.
- **Nicht erlaubt** sind fremde Go-Software jeder Art (Spiel- und Analysesoftware, Löser für Leben und Tod, neuronale Netze), eine selbst geschriebene automatische Suche nach dem Ergebnis, Nachschlagen im Internet oder in Datenbanken und das Befragen anderer.
- Trage im Bogen unter `hilfsmittel` ein, was du benutzt hast (zum Beispiel „keine“ oder „eigenes Skript zum Nachspielen und Freiheitenzählen“).

## Arbeiten in Etappen

Du darfst die Unterlagen in mehreren Etappen bearbeiten und **Teilbögen** abgeben. Ein Teilbogen hat dasselbe Format und dasselbe `manifestSha256`, enthält aber nur die Kennungen dieser Etappe. Halte die Reihenfolge der Vorlage ein. Jede Kennung steht in genau einem Teilbogen; ein abgegebenes Urteil wird später nicht geändert. Die Teilbögen werden danach mechanisch zu einem Bogen vereint.

Wenn du die Zeit je Unterlage mit einer Uhr messen kannst, trage sie als `dauerSekunden` ein. Schätze sie nicht; ohne Messung lass das Feld weg.

## Antwortformat

Gib **eine JSON-Datei** je Bogen oder Teilbogen zurück:

```json
{
  "manifestSha256": "<Wert aus manifest.json, Feld manifestSha256>",
  "beurteiler": "KI",
  "hilfsmittel": "keine",
  "antworten": [
    {"id": "U-xxxxxx", "kategorie": "tot", "begruendung": "…", "sicherheit": "sicher"},
    {"id": "U-yyyyyy", "kategorie": "ko_zugabhaengig", "urteilSchwarzAmZug": "lebendig", "urteilWeissAmZug": "tot", "begruendung": "…", "sicherheit": "eher_sicher", "offen": "…"}
  ]
}
```

Im vollständigen Bogen kommt jede Kennung der Vorlage (`bogen-vorlage.json`) **genau einmal** vor. Das Schema steht in `bogen-schema.json`.

## Wichtig

- Du kennst nicht, woher die Stellungen stammen, und sollst es nicht erraten. Beurteile nur, was du siehst.
- Dein Urteil ist eine Beurteilung, keine Wahrheit. Ehrliche Unsicherheit ist ausdrücklich erwünscht.
- Arbeite jede Unterlage für sich; vergleiche Unterlagen nicht untereinander.
