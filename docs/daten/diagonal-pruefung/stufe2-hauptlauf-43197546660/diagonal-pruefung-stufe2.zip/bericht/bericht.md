# Diagonalprüfung, Stufe 2: Übereinstimmung mit GNU Go (Schicht A)

GNU Gos Tot-Liste ist der **Maßstab dieser Messung, nicht die Wahrheit** (§5, §6). Übereinstimmung ist nicht Richtigkeit; ein Standardwechsel oder eine Kandidatur folgt daraus nicht (§8). Betroffenheit und Übereinstimmung sind keine Verbesserung.

Plan: 2118 Stellungen in 43 Paketen (Paketgröße 50, Seed-Basis 1); betroffen S 658, V 1060; Kontrolle S 200, V 200.

## Kontrollen

| Kontrolle | Ergebnis |
|---|---|
| Pakete vollständig | bestanden |
| Köpfe: gleiche Fassung der Engine, gleicher Plan, gleiche GNU-Go-Version und -Argumente, kein Paketfehler | **NICHT bestanden** (2): Paket 19: imageVersion "20261111.370.1" statt "20261101.360.1" | Paket 22: imageVersion "20261111.370.1" statt "20261101.360.1" |
| Vollständigkeit: jede Kennung des Plans genau einmal mit Status | bestanden |
| Seeds gleich fortsetzungsSeed(Basis, Gruppe, Quelle, Nr., Index) | bestanden |
| Status jeder Ergebniszeile (gueltig, ausfall oder pflichtfehler, mit den zugehörigen Feldern) | bestanden |
| Pflichtfehler (Daten, Replay, abweichendes Brett, ungültige Antworten, Abgleich mit Stufe 1) | bestanden |
| Ausfallgrenze (mehr als 5 % je Stellungsart, betroffen und Kontrolle getrennt) | bestanden |
| Fallabdeckung der Wiederholbarkeit (sonst KEIN URTEIL) | bestanden |

**UNGÜLTIG, KEIN URTEIL.** Gründe: Köpfe: gleiche Fassung der Engine, gleicher Plan, gleiche GNU-Go-Version und -Argumente, kein Paketfehler: 2 (z. B. Paket 19: imageVersion "20261111.370.1" statt "20261101.360.1")

## Ausfälle (einzeln, §16.7)

Ausfälle sind nicht zufällig (schwierige Stellungen, Absturz durch die Stellung selbst). **Jeder ungeklärte Ausfall in einer betroffenen Stellung verhindert die positive Kandidatur**, auch unter der Berichtsgrenze.

Keine Ausfälle.

