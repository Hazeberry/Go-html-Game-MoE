# Unterlage U-f56b4d

Beurteile die mit `@` markierte Kette: Ist sie lebendig, tot, in Seki, vom Ko oder vom Zug abhängig, oder nicht entscheidbar? Die Anleitung steht in `anleitung-beurteiler.md`.

- **Markierte Kette:** Schwarz, 10 Steine: G4 H4 J4 G3 J3 K3 F2 G2 H2 G1
- **Stellung:** nach Zug 304 (Zählung ab 1, Pässe eingerechnet); die Partie ist beendet (zwei Pässe in Folge)
- **Als Nächstes am Zug wäre:** Schwarz
- **Regeln:** chinesisch (Flächenzählung), Komi 7,5
- **Gefangene:** Schwarz hat 13 Steine geschlagen, Weiß 14
- **Pässe am Ende:** 2 in Folge, zuletzt von Weiß
- **Ko-Punkt (sofortiges Zurücknehmen verboten):** keiner
- **Letzte 10 Züge:** 295. Schwarz O14; 296. Weiß pass; 297. Schwarz P2; 298. Weiß P1; 299. Schwarz O1; 300. Weiß P4; 301. Schwarz Q1; 302. Weiß Q3; 303. Schwarz pass; 304. Weiß pass

## Brett

```
    A B C D E F G H J K L M N O P Q R S T
19  . . . . . O O X . X X X X O O O . O .  19
18  O O O X . O X . X . X O O O O O O X .  18
17  . O X X O O X X . X X O O X O . O . .  17
16  O X X O O O X . X . . X X X X O O O O  16
15  . O X O . O X . . X . X . X O O O X O  15
14  O O O X O O X . X . X . . X X O X X X  14
13  . O X X X X . X . . . . X X X X . X .  13
12  O X X . . . . . . . X . X O X X X . X  12
11  . O X . . X X . . . . X O O O X O X X  11
10  O O X . . . . . X . X X X X O O O O X  10
 9  . O X . . . . . . X O X X X X X X O O   9
 8  O X . X . . . X X X O O O X X . X O .   8
 7  O X X X . . X O X O O O X X O X X O .   7
 6  O O O X X . X O O O X X O O O O X O .   6
 5  O . O O X X O O O O . X O O O O O O X   5
 4  O O X O X O @ @ @ O O X X O O . O X .   4
 3  X X X O O O @ . @ @ O X O O X O O O X   3
 2  . X O O O @ @ @ O O O X O X X O O X X   2
 1  . . . . O O @ . X O . O O X . X . . .   1
    A B C D E F G H J K L M N O P Q R S T
```

`X` Schwarz, `O` Weiß, `.` leer, `@` markierte Kette.

## Zuggeschichte (SGF, alle Züge bis zur Stellung)

```
(;GM[1]FF[4]CA[UTF-8]SZ[19]KM[7.5]RU[Chinese]PB[Schwarz]PW[Weiss]
;B[cq];W[dd];B[ck];W[qd];B[ip];W[qp];B[oq];W[po];B[ij];W[np]
;B[mp];W[nq];B[nr];W[mq];B[lq];W[mo];B[lp];W[mr];B[lr];W[ph]
;B[lo];W[mn];B[ln];W[ml];B[lk];W[oc];B[pc];W[pd];B[od];W[ob]
;B[df];W[fd];B[ge];W[de];B[ce];W[ef];B[eg];W[ff];B[fg];W[cf]
;B[dg];W[bf];B[cg];W[bg];B[bh];W[be];B[bd];W[bc];B[cc];W[bb]
;B[cd];W[cb];B[dc];W[ec];B[gf];W[dp];B[eo];W[dq];B[cp];W[fp]
;B[fo];W[do];B[dn];W[co];B[bo];W[cn];B[cm];W[bn];B[bm];W[bp]
;B[bq];W[ao];B[gp];W[fq];B[gq];W[cr];B[br];W[dr];B[fr];W[fe]
;B[mh];W[oe];B[nd];W[pr];B[ne];W[lc];B[of];W[pe];B[le];W[ic]
;B[id];W[jd];B[je];W[kd];B[hc];W[oj];B[ib];W[ll];B[jc];W[km]
;B[im];W[kk];B[kj];W[ke];B[kf];W[ms];B[jk];W[kl];B[lj];W[ls]
;B[kb];W[lb];B[ld];W[kr];B[kc];W[er];B[gr];W[og];B[ng];W[pf]
;B[oh];W[oi];B[pg];W[qg];B[og];W[am];B[qh];W[qj];B[pi];W[pj]
;B[rg];W[al];B[bl];W[bk];B[dl];W[bj];B[cj];W[bi];B[ci];W[ah]
;B[ch];W[kq];B[qf];W[qc];B[re];W[kp];B[ri];W[rj];B[sj];W[sk]
;B[si];W[rl];B[gd];W[fb];B[gb];W[rd];B[ep];W[ka];B[ja];W[eq]
;B[la];W[mc];B[md];W[mb];B[nc];W[nb];B[ma];W[ir];B[iq];W[ga]
;B[ha];W[fa];B[gc];W[fc];B[mk];W[nk];B[nj];W[ni];B[mj];W[jo]
;B[nl];W[io];B[ok];W[hn];B[en];W[go];B[gn];W[ho];B[gm];W[om]
;B[nm];W[nn];B[mm];W[lm];B[on];W[no];B[pm];W[pn];B[ol];W[rn]
;B[qm];W[hm];B[hl];W[jm];B[il];W[qi];B[ph];W[rm];B[qn];W[qo]
;B[ql];W[mi];B[li];W[oo];B[qk];W[rk];B[pk];W[se];B[sf];W[sd]
;B[jl];W[in];B[kn];W[jn];B[na];W[oa];B[pb];W[ka];B[la];W[qe]
;B[rf];W[om];B[nk];W[on];B[ak];W[an];B[hr];W[jr];B[hp];W[jp]
;B[is];W[fs];B[gs];W[es];B[ma];W[pa];B[ai];W[aj];B[qa];W[qb]
;B[ag];W[af];B[aq];W[ap];B[dm];W[nh];B[mg];W[na];B[ka];W[]
;B[pc];W[pb];B[sh];W[];B[ee];W[ed];B[db];W[ad];B[sr];W[rq]
;B[rr];W[qr];B[sq];W[sp];B[so];W[ro];B[rp];W[qq];B[kh];W[]
;B[if];W[];B[hg];W[];B[gi];W[];B[fi];W[];B[rb];W[ra]
;B[ac];W[ab];B[jq];W[js];B[nf];W[];B[or];W[os];B[ns];W[op]
;B[ps];W[pq];B[];W[])
```
