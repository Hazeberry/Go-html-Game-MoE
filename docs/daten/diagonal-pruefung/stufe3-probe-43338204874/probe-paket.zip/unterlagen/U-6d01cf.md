# Unterlage U-6d01cf

Beurteile die mit `@` markierte Kette: Ist sie lebendig, tot, in Seki, vom Ko oder vom Zug abhängig, oder nicht entscheidbar? Die Anleitung steht in `anleitung-beurteiler.md`.

- **Markierte Kette:** Weiß, 1 Stein: H6
- **Stellung:** nach Zug 301 (Zählung ab 1, Pässe eingerechnet); die Partie ist nicht beendet
- **Als Nächstes am Zug wäre:** Weiß
- **Regeln:** chinesisch (Flächenzählung), Komi 7,5
- **Gefangene:** Schwarz hat 35 Steine geschlagen, Weiß 10
- **Pässe am Ende:** keine
- **Ko-Punkt (sofortiges Zurücknehmen verboten):** A3
- **Letzte 10 Züge:** 292. Weiß D9; 293. Schwarz D10; 294. Weiß F12; 295. Schwarz G19; 296. Weiß A1; 297. Schwarz H19; 298. Weiß A3; 299. Schwarz J18; 300. Weiß S13; 301. Schwarz A2

## Brett

```
    A B C D E F G H J K L M N O P Q R S T
19  . . X . . . X X O . . X O . O X X . .  19
18  X X . X X . X . X O O X O . . O X . .  18
17  O X X O O X . X O O X X O O . O X X X  17
16  O O O O O X X . X X . X X O O . O O O  16
15  . . O O X . O X X X X X O . . O . . .  15
14  . . . O X . O X O O O X O O O . O . .  14
13  . . . . O . O X O . O O X O X O O O .  13
12  O O O O O O . O O O O O X X X X O X .  12
11  X X X X X O O O O X O X X X X X X O .  11
10  . X X X X X X O X X O O O X . . X O .  10
 9  X . . O . X O X X . X O X X X X O . O   9
 8  . X . . X X O O X X X O X . X . O O X   8
 7  X X X X X O O . O . . X . X X X X X X   7
 6  . X . X O . . @ X X X X . . X . . . X   6
 5  . . . X O . O X O O X . X . . . X X .   5
 4  X X X O O O X X O X X X X X . X X . X   4
 3  . X O O O X . X O O X O X O X X O X .   3
 2  X O O X X X . X O O O O O O O O O X .   2
 1  O O X X . . . . . . . . . . . . . . .   1
    A B C D E F G H J K L M N O P Q R S T
```

`X` Schwarz, `O` Weiß, `.` leer, `@` markierte Kette.

## Zuggeschichte (SGF, alle Züge bis zur Stellung)

```
(;GM[1]FF[4]CA[UTF-8]SZ[19]KM[7.5]RU[Chinese]PB[Schwarz]PW[Weiss]
;B[cc];W[dc];B[db];W[cd];B[dd];W[ec];B[eb];W[cb];B[bc];W[ce]
;B[fc];W[ed];B[fd];W[de];B[lc];W[kb];B[kc];W[jc];B[jd];W[ic]
;B[id];W[hd];B[he];W[ge];B[hc];W[hb];B[gd];W[gf];B[ib];W[jb]
;B[gb];W[ia];B[qc];W[ck];B[ph];W[qf];B[ee];W[dd];B[ef];W[dq]
;B[cp];W[cq];B[bq];W[br];B[bp];W[dp];B[do];W[eo];B[dn];W[jq]
;B[hq];W[qq];B[pq];W[pr];B[oq];W[or];B[qp];W[nq];B[np];W[op]
;B[pp];W[oo];B[mq];W[nr];B[rq];W[qr];B[rr];W[mp];B[lp];W[no]
;B[mo];W[mn];B[np];W[mr];B[mp];W[lr];B[lb];W[nc];B[md];W[nd]
;B[ne];W[me];B[le];W[mf];B[lf];W[lg];B[mg];W[nf];B[oe];W[of]
;B[mh];W[kg];B[ln];W[mm];B[lm];W[ll];B[kl];W[lk];B[kk];W[kj]
;B[jj];W[ki];B[ml];W[nl];B[mk];W[lj];B[nm];W[nn];B[om];W[pn]
;B[on];W[po];B[pm];W[rp];B[qo];W[qn];B[ro];W[rn];B[sp];W[pe]
;B[nk];W[od];B[il];W[km];B[kn];W[jm];B[jn];W[im];B[in];W[hn]
;B[hm];W[hl];B[jl];W[gm];B[ho];W[im];B[hk];W[gk];B[gj];W[hj]
;B[ik];W[gi];B[fj];W[fi];B[fk];W[gl];B[fl];W[fm];B[em];W[en]
;B[dm];W[go];B[gp];W[io];B[hp];W[fp];B[fq];W[eq];B[fr];W[ir]
;B[hr];W[ip];B[ol];W[mj];B[nj];W[ni];B[oi];W[hi];B[ji];W[jh]
;B[ih];W[ig];B[hf];W[gg];B[hg];W[hh];B[er];W[ii];B[qm];W[rl]
;B[rm];W[ql];B[sn];W[iq];B[je];W[kf];B[ke];W[jf];B[mi];W[lh]
;B[li];W[kh];B[nh];W[ng];B[og];W[pg];B[oh];W[qh];B[qi];W[ri]
;B[qj];W[rj];B[rh];W[qg];B[dr];W[cr];B[ds];W[qk];B[pk];W[pj]
;B[pi];W[oj];B[ni];W[if];B[ie];W[ih];B[ei];W[eh];B[di];W[dh]
;B[ci];W[ch];B[bi];W[bh];B[dk];W[cl];B[bn];W[bm];B[cm];W[dl]
;B[el];W[dj];B[ej];W[ek];B[ok];W[dk];B[bl];W[bk];B[am];W[df]
;B[ak];W[aj];B[ai];W[al];B[bm];W[eg];B[ak];W[ah];B[bj];W[bd]
;B[bb];W[ac];B[ab];W[ad];B[ca];W[mc];B[ld];W[mb];B[la];W[ma]
;B[sl];W[sk];B[sm];W[pc];B[qb];W[pb];B[pa];W[oa];B[qa];W[qd]
;B[rc];W[rd];B[sc];W[sd];B[ij];W[kp];B[ko];W[jo];B[kq];W[kr]
;B[jp];W[jr];B[kp];W[lq];B[cs];W[bs];B[ar];W[aq];B[ap];W[ep]
;B[cj];W[dk];B[dj];W[fh];B[ga];W[as];B[ha];W[aq];B[ib];W[rg]
;B[ar])
```
