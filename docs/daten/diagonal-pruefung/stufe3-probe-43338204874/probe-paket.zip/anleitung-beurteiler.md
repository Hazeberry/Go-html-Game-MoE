# Anleitung für die Beurteilung

Du bekommst eine Reihe von Unterlagen (`unterlagen/U-….md`, dazu je eine SGF-Datei). In jeder Unterlage ist **eine Kette** von Steinen mit `@` markiert. Beurteile **jede Unterlage einzeln und unabhängig**, nur nach den Regeln des Go und nach dem, was auf dem Brett und in der Zuggeschichte steht.

## Aufgabe

Beurteile, ob die markierte Kette bei bestem Spiel beider Seiten (chinesische Regeln, Flächenzählung) **bestehen bleibt oder gefangen wird**. Die Stellung kann beendet oder mitten in der Partie sein; die Unterlage sagt es. Nutze die vollständige Zuggeschichte (SGF), wenn Ko, Superko oder die Reihenfolge der Züge eine Rolle spielen.

## Kategorien (genau eine je Unterlage)

- `lebendig`: Die Kette bleibt bestehen (zwei echte Augen, ausreichende Freiheiten im Kampf oder Verbindung mit einer lebenden Gruppe), auch wenn die Gegenseite zuerst zieht.
- `tot`: Die Kette wird gefangen, auch wenn die eigene Seite zuerst zieht.
- `seki`: Beide Seiten können die Kette bzw. die gegnerische Gruppe nicht fangen; beide bleiben bestehen, ohne Gebiet.
- `ko_zugabhaengig`: Das Ergebnis hängt von einem Ko oder davon ab, wer am Zug ist. Gib dann **zusätzlich** das Urteil bei Zug von Schwarz (`urteilSchwarzAmZug`) und bei Zug von Weiß (`urteilWeissAmZug`) an, jeweils `lebendig`, `tot`, `seki` oder `nicht_entscheidbar`.
- `nicht_entscheidbar`: Du kannst es nach sorgfältigem Lesen nicht entscheiden. Das ist eine ehrliche Antwort und besser als Raten.

## Begründung und Sicherheit

Schreibe zu jeder Unterlage eine **Begründung** nach allgemeinen Go-Kriterien: echte und falsche Augen, Freiheiten, Verbindungen und Schnittpunkte, Randlage und Ecke, Seki, Ko, Lesen der entscheidenden Zugfolge. Nenne die Koordinaten der entscheidenden Punkte. Gib die **Sicherheit** an:

- `sicher`: Du hast die Stellung bis zum Ergebnis gelesen und siehst keine Alternative.
- `eher_sicher`: Du hältst das Urteil für richtig, hast aber nicht jede Variante zu Ende gelesen.
- `unsicher`: Du bist dir nicht sicher. Dann schreibe unter `offen`, was offen bleibt.

Bei `eher_sicher`, `unsicher` und `nicht_entscheidbar` ist `offen` Pflicht.

## Antwortformat

Gib **eine JSON-Datei** zurück:

```json
{
  "manifestSha256": "<Wert aus manifest.json, Feld manifestSha256>",
  "antworten": [
    {"id": "U-xxxxxx", "kategorie": "tot", "begruendung": "…", "sicherheit": "sicher"},
    {"id": "U-yyyyyy", "kategorie": "ko_zugabhaengig", "urteilSchwarzAmZug": "lebendig", "urteilWeissAmZug": "tot", "begruendung": "…", "sicherheit": "eher_sicher", "offen": "…"}
  ]
}
```

Jede Kennung der Vorlage (`bogen-vorlage.json`) kommt **genau einmal** vor. Das Schema steht in `bogen-schema.json`.

## Wichtig

- Du kennst nicht, woher die Stellungen stammen, und sollst es nicht erraten. Beurteile nur, was du siehst.
- Dein Urteil ist eine Beurteilung, keine Wahrheit. Ehrliche Unsicherheit ist ausdrücklich erwünscht.
- Arbeite jede Unterlage für sich; vergleiche Unterlagen nicht untereinander.
