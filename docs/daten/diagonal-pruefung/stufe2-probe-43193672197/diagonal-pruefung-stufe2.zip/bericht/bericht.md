# Diagonalprüfung, Stufe 2: Probe (nur technisch)

Zweck: Dauer messen und den Ablauf mit echtem GNU Go prüfen (§16.6). **Keine Schicht-A-Zahlen, keine Tot-Listen.** Die Stellungen laufen im Hauptlauf neu.

Plan: 24 Stellungen (betroffen S 10, V 10; Kontrolle S 2, V 2).

## Kontrollen

| Kontrolle | Ergebnis |
|---|---|
| Pakete vollständig | bestanden |
| Köpfe: gleiche Fassung der Engine, gleicher Plan, gleiche GNU-Go-Version und -Argumente, kein Paketfehler | bestanden |
| Vollständigkeit: jede Kennung des Plans genau einmal mit Status | bestanden |
| Seeds gleich fortsetzungsSeed(Basis, Gruppe, Quelle, Nr., Index) | bestanden |
| Status jeder Ergebniszeile (gueltig, ausfall oder pflichtfehler, mit den zugehörigen Feldern) | bestanden |
| Pflichtfehler (Daten, Replay, abweichendes Brett, ungültige Antworten, Abgleich mit Stufe 1) | bestanden |
| Ausfallgrenze (mehr als 5 % je Stellungsart, betroffen und Kontrolle getrennt) | bestanden |

**Probe gültig (technisch).**

## Dauer je Stellung (beide Referenzläufe samt Wiederholungsversuchen, Sekunden)

| Art | n | Median | 95 %-Quantil | Maximum |
|---|---:|---:|---:|---:|
| alle | 24 | 0,5 | 0,8 | 1,5 |
| S | 12 | 0,2 | 0,6 | 0,6 |
| V | 12 | 0,6 | 1,5 | 1,5 |

Regel für die Paketgröße (§16.6): Maximum × 50 ≤ 60 Minuten: Paketgröße 50 bleibt. Das ist ein rechnerischer Hinweis; die Entscheidung steht vor dem Go zum Hauptlauf im Doc.

Ausfälle: 0.

