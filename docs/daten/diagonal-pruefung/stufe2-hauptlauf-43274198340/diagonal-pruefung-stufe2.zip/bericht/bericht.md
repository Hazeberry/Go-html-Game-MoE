# Diagonalprüfung, Stufe 2: Übereinstimmung mit GNU Go (Schicht A)

GNU Gos Tot-Liste ist der **Maßstab dieser Messung, nicht die Wahrheit** (§5, §6). Übereinstimmung ist nicht Richtigkeit; ein Standardwechsel oder eine Kandidatur folgt daraus nicht (§8). Betroffenheit und Übereinstimmung sind keine Verbesserung.

Plan: 2118 Stellungen in 43 Paketen (Paketgröße 50, Seed-Basis 1); betroffen S 658, V 1060; Kontrolle S 200, V 200.

## Kontrollen

| Kontrolle | Ergebnis |
|---|---|
| Pakete vollständig | bestanden |
| Köpfe: gleiche Fassung der Engine, gleicher Plan, gleiche GNU-Go-Version und -Argumente, kein Paketfehler | bestanden |
| Vollständigkeit: jede Kennung des Plans genau einmal mit Status | bestanden |
| Seeds gleich fortsetzungsSeed(Basis, Gruppe, Quelle, Nr., Index) | bestanden |
| Status jeder Ergebniszeile (gueltig, ausfall oder pflichtfehler, mit den zugehörigen Feldern) | bestanden |
| Pflichtfehler (Daten, Replay, abweichendes Brett, ungültige Antworten, Abgleich mit Stufe 1) | bestanden |
| Ausfallgrenze (mehr als 5 % je Stellungsart, betroffen und Kontrolle getrennt) | bestanden |
| Fallabdeckung der Wiederholbarkeit (sonst KEIN URTEIL) | bestanden |

Alle Pflichtkontrollen bestanden.

Runner-Image der Pakete (nur protokolliert, kein Gültigkeitskriterium; gleich geprüft werden GNU-Go-Version, Paketversion und Argumente): 20261101.360.1 in 27 Paketen; 20261111.370.1 in 12 Paketen; 20261111.127.1 in 4 Paketen.

## Ausfälle (einzeln, §16.7)

Ausfälle sind nicht zufällig (schwierige Stellungen, Absturz durch die Stellung selbst). **Jeder ungeklärte Ausfall in einer betroffenen Stellung verhindert die positive Kandidatur**, auch unter der Berichtsgrenze.

Keine Ausfälle.

## Kennzahlen (Steine; behoben und neu entstanden getrennt, nie nur als Saldo)

behoben = bei aus von GNU Go abweichend, bei an gleich; neu entstanden = bei aus gleich, bei an abweichend; unverändert abweichend = bei beiden abweichend. „zusätzlich tot“ = bei an tot, bei aus lebend; „wieder lebendig“ umgekehrt. Stellungen derselben Partie sind nicht unabhängig.

| Art | Kategorie | Gruppe | Stellungen | Steine behoben (zusätzlich tot / wieder lebendig) | Steine neu entstanden (zusätzlich tot / wieder lebendig) | Steine unverändert abweichend (GNU tot / GNU lebend) | Stellungen mit behoben | mit neu | beides | ohne Änderung |
|---|---|---|---:|---|---|---|---:|---:|---:|---:|
| S | betroffen | Fuego 100 Spiele | 95 | 1506 (1407 / 99) | 0 (0 / 0) | 6 (0 / 6) | 95 | 0 | 0 | 0 |
| S | betroffen | Fuego 50 Spiele | 133 | 1898 (1771 / 127) | 7 (7 / 0) | 147 (54 / 93) | 132 | 1 | 0 | 0 |
| S | betroffen | GNU Go ohne Vorgabe | 430 | 7300 (6988 / 312) | 0 (0 / 0) | 166 (48 / 118) | 430 | 0 | 0 | 0 |
| S | betroffen | Summe (nicht gewichtet) | 658 | 10704 (10166 / 538) | 7 (7 / 0) | 319 (102 / 217) | 657 | 1 | 0 | 0 |
| S | kontrolle | alte PWA | 20 | 0 (0 / 0) | 0 (0 / 0) | 11 (0 / 11) | 0 | 0 | 0 | 20 |
| S | kontrolle | Fuego 100 Spiele | 35 | 0 (0 / 0) | 0 (0 / 0) | 43 (12 / 31) | 0 | 0 | 0 | 35 |
| S | kontrolle | Fuego 50 Spiele | 76 | 0 (0 / 0) | 0 (0 / 0) | 112 (33 / 79) | 0 | 0 | 0 | 76 |
| S | kontrolle | GNU Go ohne Vorgabe | 69 | 0 (0 / 0) | 0 (0 / 0) | 9 (6 / 3) | 0 | 0 | 0 | 69 |
| S | kontrolle | Summe (nicht gewichtet) | 200 | 0 (0 / 0) | 0 (0 / 0) | 175 (51 / 124) | 0 | 0 | 0 | 200 |
| V | betroffen | alte PWA | 21 | 225 (189 / 36) | 148 (146 / 2) | 329 (81 / 248) | 11 | 8 | 2 | 0 |
| V | betroffen | Fuego 100 Spiele | 131 | 1942 (1743 / 199) | 546 (514 / 32) | 469 (143 / 326) | 106 | 17 | 8 | 0 |
| V | betroffen | Fuego 50 Spiele | 174 | 2452 (2152 / 300) | 478 (430 / 48) | 509 (171 / 338) | 149 | 20 | 5 | 0 |
| V | betroffen | GNU Go ohne Vorgabe | 734 | 13841 (12577 / 1264) | 430 (300 / 130) | 1911 (1118 / 793) | 715 | 7 | 12 | 0 |
| V | betroffen | Summe (nicht gewichtet) | 1060 | 18460 (16661 / 1799) | 1602 (1390 / 212) | 3218 (1513 / 1705) | 981 | 52 | 27 | 0 |
| V | kontrolle | alte PWA | 21 | 0 (0 / 0) | 0 (0 / 0) | 142 (19 / 123) | 0 | 0 | 0 | 21 |
| V | kontrolle | Fuego 100 Spiele | 52 | 0 (0 / 0) | 0 (0 / 0) | 285 (119 / 166) | 0 | 0 | 0 | 52 |
| V | kontrolle | Fuego 50 Spiele | 87 | 0 (0 / 0) | 0 (0 / 0) | 796 (241 / 555) | 0 | 0 | 0 | 87 |
| V | kontrolle | GNU Go ohne Vorgabe | 40 | 0 (0 / 0) | 0 (0 / 0) | 270 (162 / 108) | 0 | 0 | 0 | 40 |
| V | kontrolle | Summe (nicht gewichtet) | 200 | 0 (0 / 0) | 0 (0 / 0) | 1493 (541 / 952) | 0 | 0 | 0 | 200 |

## Punkte (Abstand des Standes zum Referenzstand aus GNU Gos Tot-Liste)

S: Fläche gegen `final_score`, Territory gegen die App-Rechnung auf GNU Gos Tot-Liste. V: „mit Annahmen“ gegen die App-Rechnung auf GNU Gos Tot-Liste (kein `final_score`). „näher“ und „weiter“ vergleichen den Abstand bei an mit dem bei aus.

| Art | Kategorie | Gruppe | Wertung | n | gleich bei aus | gleich bei an | bei an näher | bei an weiter | Abstand gleich | Sieger wie Referenz aus | an |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| S | betroffen | Summe (nicht gewichtet) | flaeche | 658 | 0 | 643 | 653 | 5 | 0 | 460 | 655 |
| S | betroffen | Summe (nicht gewichtet) | territory | 658 | 0 | 644 | 653 | 5 | 0 | 588 | 656 |
| S | kontrolle | Summe (nicht gewichtet) | flaeche | 200 | 190 | 190 | 0 | 0 | 200 | 197 | 197 |
| S | kontrolle | Summe (nicht gewichtet) | territory | 200 | 190 | 190 | 0 | 0 | 200 | 199 | 199 |
| V | betroffen | Summe (nicht gewichtet) | flaeche | 1060 | 14 | 829 | 976 | 84 | 0 | 784 | 1011 |
| V | betroffen | Summe (nicht gewichtet) | territory | 1060 | 14 | 829 | 976 | 84 | 0 | 867 | 1015 |
| V | kontrolle | Summe (nicht gewichtet) | flaeche | 200 | 126 | 126 | 0 | 0 | 200 | 178 | 178 |
| V | kontrolle | Summe (nicht gewichtet) | territory | 200 | 126 | 126 | 0 | 0 | 200 | 179 | 179 |

Je Gruppe stehen die Zahlen in `bericht.json`. Die Kontrollstichprobe geht in keine Kennzahl der betroffenen Stellungen ein und misst nicht die Wirkung des Schalters (§16.4).

## Mechanische Auswahl für Stufe 3 (§16.8, ohne Sicht auf Urteile)

- B1 (alle neu entstandenen Abweichungen, ohne Deckel): 356 Ketten.
- B2: 6820 Kandidaten, davon 60 gezogen (Deckel 60); Zellen (Art|Klasse|Richtung): {"S|behoben|GNU lebend":56,"S|behoben|GNU tot":2114,"S|unveraendert|GNU lebend":41,"S|unveraendert|GNU tot":16,"V|behoben|GNU lebend":262,"V|behoben|GNU tot":3425,"V|unveraendert|GNU lebend":398,"V|unveraendert|GNU tot":508}; Zuteilung: {"S|behoben|GNU lebend":1,"S|behoben|GNU tot":18,"S|unveraendert|GNU lebend":1,"S|unveraendert|GNU tot":1,"V|behoben|GNU lebend":2,"V|behoben|GNU tot":30,"V|unveraendert|GNU lebend":3,"V|unveraendert|GNU tot":4}.
- Stellungen mit Seki-Eintrag bei GNU Go: 2.
- Ausfälle in betroffenen Stellungen haben keine GNU-Go-Liste, gehen weder in B1 noch in B2 ein und stehen oben als ungeklärt.

## Grenzen

- GNU Go als Maßstab, ohne Beurteilung (Stufe 3 steht aus).
- Die Prüfdaten stammen aus denselben Archiven wie die Entwicklungsdaten und gelten nicht für Menschen.
- Ko und Superko wurden beim Einspielen nicht geprüft (wie Stufe 1).
- Die GNU-Go-Fassung des Archivlaufs ist nicht bekannt; diese Messung protokolliert ihre Fassung (Köpfe der Pakete).
- Zeit je Stellung und Timeouts sind Setzungen (§16.3 Nr. 7).
